package com.okta.examples.originexample.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.okta.examples.originexample.model.User;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import javax.xml.bind.DatatypeConverter;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Claims;


public class RequestContextUser {

    private static final Logger log = LoggerFactory.getLogger(RequestContextUser.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    public  static final String USER_HEADER = "x-userinfo";
    public static final String AUTH_HDR = "authorization";

    public static User findUser() {
        String userInfoHeader;
        HttpServletRequest req;

        log.error("in findUser ..........................");

        try {
            RequestAttributes reqAttr = RequestContextHolder.currentRequestAttributes();

            int scope = RequestAttributes.SCOPE_REQUEST;
            String[] aNames = reqAttr.getAttributeNames(scope);
            for (String name : aNames) {
                StringBuilder sb = new StringBuilder("SCOPE: REQUEST::: attr: ");
                sb.append(name);
                sb.append(" val: ");
                sb.append(reqAttr.getAttribute(name, scope));
                log.error(sb.toString());
            }
            scope = RequestAttributes.SCOPE_SESSION;
            aNames = reqAttr.getAttributeNames(scope);
            for (String name : aNames) {
                StringBuilder sb = new StringBuilder("SCOPE: SESSION::: attr: ");
                sb.append(name);
                sb.append(" val: ");
                sb.append(reqAttr.getAttribute(name, scope));
                log.error(sb.toString());
            }

            log.error ("reqAttr class : " + reqAttr.getClass().getName());
            log.error ("reqAttr getReq : " + ((ServletRequestAttributes) reqAttr).getRequest());
            log.error ("user header : " + ((ServletRequestAttributes) reqAttr).getRequest().getHeader(USER_HEADER));
            final String authHdr = ((ServletRequestAttributes) reqAttr).getRequest().getHeader(AUTH_HDR);
            log.error ("auth header : " + ((ServletRequestAttributes) reqAttr).getRequest().getHeader(AUTH_HDR));

            User userFromAuth = decodeAndExtractUserData(authHdr);
            if (userFromAuth != null) {
                req = ((ServletRequestAttributes) reqAttr).getRequest();
                req.setAttribute(User.class.getName(), userFromAuth);
                return userFromAuth;
            }
            
            /**if (
                reqAttr instanceof ServletRequestAttributes &&
                (req = ((ServletRequestAttributes) reqAttr).getRequest()) != null &&
                (userInfoHeader = req.getHeader(USER_HEADER)) != null
            ) {
                log.error("XXXXXXXXXXXXX-Found user info from {} header with value {}", USER_HEADER, userInfoHeader);
                log.debug("Found user info from {} header with value {}", USER_HEADER, userInfoHeader);

                // decode x-userinfo header here ????

                User user =  mapper.readValue(userInfoHeader, User.class);
                req.setAttribute(User.class.getName(), user);
                return user;
            }*/


        } catch (Exception e) {
            log.error("Unable to resolve user from {} header", USER_HEADER, e);
        }

        log.debug("Did not find user from {} header.", USER_HEADER);
        return null;
    }

    private static User decodeAndExtractUserData(String authHdr) {
        log.error("[[[ in decodeAndExtractUserData ..... ]]]]");

        // 1. strip bearer text
        final String bearer = "Bearer ";
        final String clientSecret = "XaewflSG_nlmMm07971BHd69Qj-fTrqdQXtN2xwd";
        log.error("Auth hdr : " + authHdr);
        // Bearer eyJraWQiOiJOdFl5al9uYkhUREdxOVo2c2dVaS1mS

        if (authHdr != null && authHdr.startsWith(bearer)){
            final String strippedAuthHdr =  authHdr.substring(bearer.length());
            log.error("(Stripped) Auth hdr : " + strippedAuthHdr);

            Claims c = decodeJWT(strippedAuthHdr, clientSecret);
            log.error("decoded JWT: " + c.toString());
            log.error("decoded JWT values: " + c.values());



        // 2. decode using client secret


        // 3. parse json



        // 4. create user object


        }






        return null;

    }

    public static Claims decodeJWT(String jwt, String secretKey) {
        //This line will throw an exception if it is not a signed JWS (as expected)
        Claims claims = Jwts.parser()
                .setSigningKey(DatatypeConverter.parseBase64Binary(secretKey))
                .parseClaimsJws(jwt).getBody();
        return claims;
    }

    
}