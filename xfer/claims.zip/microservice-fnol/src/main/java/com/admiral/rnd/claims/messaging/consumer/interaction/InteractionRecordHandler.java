package com.admiral.rnd.claims.messaging.consumer.interaction;

import java.io.IOException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.CarIncidentCase;
import com.admiral.rnd.claims.datamodel.events.Event;
import com.admiral.rnd.claims.db.DbHelperCarCase;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.RecordHandler;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;
import com.admiral.rnd.claims.orchestrator.exceptions.NoSuchCaseException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class InteractionRecordHandler extends RecordHandler {

    private static final Logger LOG = LoggerFactory.getLogger(InteractionRecordHandler.class);

    private final DbHelperCarCase dbAccessor;
    private final ICaseProducer caseProducer;

    public InteractionRecordHandler(ConsumerRecord<String, TopicRecord> consumerRecord, DbHelperCarCase dbAccessor, ICaseProducer caseProducer) {
        super(consumerRecord);
        this.dbAccessor = dbAccessor;
        this.caseProducer = caseProducer;
    }

    public void run() {
        try {
            Event event  = getEventObject(getEvent());

            // now we have a java object we can process the incoming event....
            processEvent(getId(), getRecordId(), event);

        } catch (JsonParseException | JsonMappingException e) {
            // unexpected event type, not for us, so leave for another handler
            LOG.info("IteractionRecordHandler: JSON mapping problem, e: " + e.getClass().getName() + " : " + e.getMessage() );
        } catch (Exception e) {
            // unexpected event type, not for us, so leave for another handler
            LOG.info("InteractionRecordHandler, e: " + e.getClass().getName() + " : " + e.getMessage() );
        }
    }

    /**
     * Convert event json into Case Interaction object.
     * 
     * @param eventJson raw json data
     * @return Event object
     * @throws JsonParseException if problem parsing json
     * @throws JsonMappingException if problem parsing json
     * @throws IOException if problem parsing json
     */
    public Event getEventObject(String eventJson) throws JsonParseException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(eventJson, Event.class);
    }

    private void processEvent(String interactionId, String ciId, Event event) {
        // just received a case interaction event
        LOG.info("handling SS Event - interactionId  : " + interactionId);
        LOG.info("handling SS Event - type           : " + event.getClass().getName());
        
        try {
            // retrieve (if exists) case associated with interaction
            CarIncidentCase ciCase = event.toCarIncidentCase(dbAccessor);
            
            // if required, post the updated case to the self-service topic
            event.postUpdatedCase(ciCase, caseProducer);
        } catch (NoSuchCaseException e) {
            LOG.info("Processing interaction, Caught NoSuchCaseException, e: " + e.getMessage());
        } catch (Exception e ) {
            LOG.info("Processing interaction, Caught " + e.getClass().getName() + ", e: " + e.getMessage());
        }
    }

}
