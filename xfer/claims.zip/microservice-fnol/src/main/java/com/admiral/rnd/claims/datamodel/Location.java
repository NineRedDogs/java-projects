package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Location extends Entity {

    @JsonProperty
    @BsonProperty
    private String description;


    @JsonProperty
    @BsonProperty
    private String line1;


    @JsonProperty
    @BsonProperty
    private String line2;


    @JsonProperty
    @BsonProperty
    private String town;


    @JsonProperty
    @BsonProperty
    private String county;


    @JsonProperty
    @BsonProperty
    private String country;


    @JsonProperty
    @BsonProperty
    private String postcode;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param description
     * @param line1
     * @param line2
     * @param town
     * @param county
     * @param country
     * @param postcode
     */
    @JsonCreator
    public Location(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("description") @BsonProperty("description") String description,
            @JsonProperty("line1") @BsonProperty("line1") String line1, 
            @JsonProperty("line2") @BsonProperty("line2") String line2, 
            @JsonProperty("town") @BsonProperty("town") String town,
            @JsonProperty("county") @BsonProperty("county") String county, 
            @JsonProperty("country") @BsonProperty("country") String country,
            @JsonProperty("postcode") @BsonProperty("postcode") String postcode) {
        super(id, createdAt, updatedAt);
        this.description = description;
        this.line1 = line1;
        this.line2 = line2;
        this.town = town;
        this.county = county;
        this.country = country;
        this.postcode = postcode;
    }

    @BsonCreator
    public Location() {
    }

    
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    
    /**
     * @return the line1
     */
    public String getLine1() {
        return line1;
    }

    
    /**
     * @param line1 the line1 to set
     */
    public void setLine1(String line1) {
        this.line1 = line1;
    }

    
    /**
     * @return the line2
     */
    public String getLine2() {
        return line2;
    }

    
    /**
     * @param line2 the line2 to set
     */
    public void setLine2(String line2) {
        this.line2 = line2;
    }

    
    /**
     * @return the town
     */
    public String getTown() {
        return town;
    }

    
    /**
     * @param town the town to set
     */
    public void setTown(String town) {
        this.town = town;
    }

    
    /**
     * @return the county
     */
    public String getCounty() {
        return county;
    }

    
    /**
     * @param county the county to set
     */
    public void setCounty(String county) {
        this.county = county;
    }

    
    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    
    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    
    /**
     * @return the postcode
     */
    public String getPostcode() {
        return postcode;
    }

    
    /**
     * @param postcode the postcode to set
     */
    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Location [description=" + description + ", line1=" + line1 + ", line2=" + line2 + ", town=" + town
                + ", county=" + county + ", country=" + country + ", postcode=" + postcode + "]";
    }


}
