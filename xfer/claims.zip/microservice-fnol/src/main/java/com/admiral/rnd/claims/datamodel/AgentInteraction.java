package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AgentInteraction extends Interaction {

    public static final String TYPE_NAME = "AgentInteraction";

    @JsonProperty
    @BsonProperty
    private String agentId;

    /**
     * @param agentId
     */
    @JsonCreator
    public AgentInteraction(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("contactId") @BsonProperty("contactId") String contactId,
            @JsonProperty("caseId") @BsonProperty("caseId") String caseId, 
            @JsonProperty("medium") @BsonProperty("medium") InteractionMediumEnum medium,
            @JsonProperty("verification") @BsonProperty("verification") InteractionVerificationEnum verification,
            @JsonProperty("agentId") @BsonProperty("agentId") String agentId) {
        super(id, createdAt, updatedAt, TYPE_NAME, contactId, caseId, medium, verification);
        this.agentId = agentId;
    }

    @BsonCreator
    public AgentInteraction() {
    }

    
    /**
     * @return the agentId
     */
    public String getAgentId() {
        return agentId;
    }

    
    /**
     * @param agentId the agentId to set
     */
    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " AgentInteraction [agentId=" + agentId + "]";
    }



}
