package com.admiral.rnd.claims;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import io.micronaut.runtime.Micronaut;

public class Application {
    private static final Logger LOG = LoggerFactory.getLogger(Application.class);

    public static void main(String[] args) {
        MDC.put("userId", "Andy_Grahame");
        LOG.debug("AJG: (D) Application: main() ...");
        LOG.error("AJG: (E) Application: main() ...");
        MDC.remove("userId");
        Micronaut.run(Application.class);
    }
}