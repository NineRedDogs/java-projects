package com.admiral.rnd.claims.datamodel.events;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.inject.Singleton;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.CarIncidentCase;
import com.admiral.rnd.claims.datamodel.Contact;
import com.admiral.rnd.claims.db.DbHelperCarCase;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

@Singleton
public class SelfServicePrimaryContactEvent extends Event {
    private static final Logger LOG = LoggerFactory.getLogger(SelfServicePrimaryContactEvent.class);
    
    // ss1
    protected static final String EVENT_NAME = "SelfServicePrimaryContactEvent";
    
    private static final List<Class<?>> validTransitions = Collections.unmodifiableList(Arrays.asList(
            SelfServiceCircumstancesEvent.class));
    
    @JsonProperty
    @BsonProperty
    private String policyNumber;
    
    @JsonProperty
    @BsonProperty
    private Contact primaryContact;

    /**
     * @param id
     * @param interactionId
     * @param policyNumber
     * @param primaryContact
     */
    @JsonCreator
    public SelfServicePrimaryContactEvent(
            @JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("interactionId") @BsonProperty("interactionId") String interactionId, 
            @JsonProperty("policyNumber") @BsonProperty("policyNumber") String policyNumber, 
            @JsonProperty("primaryContact") @BsonProperty("primaryContact") Contact primaryContact) {
        super(id, interactionId, EVENT_NAME);
        this.policyNumber = policyNumber;
        this.primaryContact = primaryContact;
    }

    @BsonCreator
    public SelfServicePrimaryContactEvent() {}

    
    /**
     * @return the policyNumber
     */
    public String getPolicyNumber() {
        return policyNumber;
    }

    
    /**
     * @param policyNumber the policyNumber to set
     */
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    
    /**
     * @return the primaryContact
     */
    public Contact getPrimaryContact() {
        return primaryContact;
    }

    
    /**
     * @param primaryContact the primaryContact to set
     */
    public void setPrimaryContact(Contact primaryContact) {
        this.primaryContact = primaryContact;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " SelfServicePrimaryContactEvent [policyNumber=" + policyNumber + ", primaryContact="
                + primaryContact + "]";
    }
    
    @Override
    protected List<Class<?>> getValidTransitions() {
        return validTransitions;
    }

    @Override
    public boolean canBeAnInitialEvent() {
        return true;
    }

    @Override
    public void addSelfServiceEventData(final CarIncidentCase ciCase, DbHelperCarCase dbAccessor) {
        // add the new CarIncidentCase instance properties with those of this SelfServiceEvent
        ciCase.setId(getId());
        final String now = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        ciCase.setCreatedAt(now);
        ciCase.setUpdatedAt(now);
        ciCase.setPolicy(dbAccessor.getPolicy(getPolicyNumber()));
        ciCase.setContacts(new ArrayList<Contact>(Arrays.asList(getPrimaryContact())));
        ciCase.setInteractions(new ArrayList<String>(Arrays.asList(getInteractionId())));
    }
    
    
    @Override
    public void postUpdatedCase(CarIncidentCase ciCase, ICaseProducer caseProducer) {
        // nothing to post - mid-way through a set of interactions ....
        LOG.info("NOT posting case to TOPIC : SelfService phase 1...");
    }
    
    public static void main(String[] args) {
        
        String t1 = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        System.out.println(t1);
        
        
    }

        
}
