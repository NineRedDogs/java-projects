package com.admiral.rnd.claims.websocket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.WsCallback;
import com.admiral.rnd.claims.datamodel.Case;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.carcase.CaseConsumer;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micronaut.websocket.WebSocketBroadcaster;
import io.micronaut.websocket.WebSocketSession;
import io.micronaut.websocket.annotation.OnClose;
import io.micronaut.websocket.annotation.OnMessage;
import io.micronaut.websocket.annotation.OnOpen;
import io.micronaut.websocket.annotation.ServerWebSocket;

@ServerWebSocket("/claims")
public class AllClaimsWsServer implements WsCallback {
    private static final Logger LOG = LoggerFactory.getLogger(AllClaimsWsServer.class);

    private final ICaseProducer caseProducer;

    private final WebSocketBroadcaster broadcaster;
    private final CaseConsumer respConsumer;

    private WebSocketSession session;

    /**
     * Constructor.
     * 
     * @param broadcaster
     */
    public AllClaimsWsServer(ICaseProducer caseProducer, 
            WebSocketBroadcaster broadcaster,
            CaseConsumer respConsumer) { 
        this.respConsumer = respConsumer;
        this.caseProducer = caseProducer;
        this.broadcaster = broadcaster;
    }

    private void out(final String msg) {
        LOG.error("---ALL-Claims WS Socket:: " + msg);
        //LOG.info("---ALL-Claims WS Socket:: " + msg);
    }

    protected String getSessionId() {
        return session.getId();
    }

    @OnOpen
    public void onOpen(WebSocketSession session) {
        this.session = session;
        String msg = "claim WS opened !";
        out("onOpen(): " + msg);
        setUpResponseHandler();
    }

    @OnMessage
    public void onMessage(
            String caseEvent,
            WebSocketSession session) {

        out("111-1 ON MESSAGE [START] called with [" + caseEvent + "] session : " + session.getId());

        if (messageParamsOk(session.getId())) {
            // add event to topic
            out("111-2 ON MESSAGE called (MESSAGE PARAMS OK)");
            caseProducer.postEvent("xxx", new TopicRecord(session.getId(), caseEvent));

        } else {
            out("111-3 ON MESSAGE called (MESSAGE PARAMS not OK)");
            out("Unexpected case Id and/or session id ... not adding to case topic .... ");
        }
        out("111-4 ON MESSAGE [END]");
    }

    private boolean messageParamsOk(String wsSessionId) {
        return (this.getSessionId().equalsIgnoreCase(wsSessionId));
    }

    @OnClose
    public void onClose(
            WebSocketSession session) {
        String msg = "case closed !";
        out("onClose(): " + msg);
    }

    /**
     * 
     * Heres an example of a method that returns a message to be broadcasted 
     * 
    @OnClose
    public Publisher<String> onClose(
            String caseId,
            WebSocketSession session) {
        String msg = "case [" + caseId + "] closed !";
        out("onClose(): " + msg);

        return session.sendAsync("xyz", isValid(response.get_id(), session));
        
        or if want to broadcast to multiple ws connections :
        
        return broadcaster.broadcast("xyz", isValid(response.get_id(), session));
    } */

    private void setUpResponseHandler() {
        respConsumer.setCallback(this);
        Thread thread = new Thread(respConsumer);
        thread.start();

        out("setUpResponseHandler (started)");
    }

    @Override
    public void caseToReturn(Case response, String caseId, String wsSessionId) {
        ObjectMapper mapper = new ObjectMapper();
        String respJson="{}";
        try {
            respJson = mapper.writeValueAsString(response);
        } catch (JsonProcessingException e) {
            out("Caught JsonProcessingException when serializing WS Response JSON object, e:" 
                    + e.getMessage());
        }
        out("send response back over ws [" + respJson + "]");

        session.sendAsync(respJson);

        // however if want to broadcast message over multiple web sockets - can use broadcast with 
        // predicate filter ...
        //
        // broadcaster.broadcastAsync(respJson, isValid(response.get_id(), session));
    }
    
    
    /**
     private Predicate<WebSocketSession> isValid(String caseId, WebSocketSession session) {
        return s -> s == session && caseId.equalsIgnoreCase(s.getUriVariables().get("caseId", String.class, null));
    }
    */

    public WebSocketBroadcaster getBroadcaster() {
        return broadcaster;
    }



}
