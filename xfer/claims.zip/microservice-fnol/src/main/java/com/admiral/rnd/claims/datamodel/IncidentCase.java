package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class IncidentCase extends Case {
    
    protected static final String TYPE_NAME = "IncidentCase";

    @JsonProperty
    @BsonProperty
    private String occurredAt;

    @JsonProperty
    @BsonProperty
    private Location location;
    
    @JsonProperty
    @BsonProperty
    private boolean seriousInjury;
    
    @JsonProperty
    @BsonProperty
    private String crimeReference;

    @JsonProperty
    @BsonProperty
    private List<EmergencyServiceEnum> emergencyServices;
    
    @JsonProperty
    @BsonProperty
    private AtFaultEnum policyHolderAtFault;


    @JsonProperty
    @BsonProperty
    private List<Contact> contacts;


    @JsonCreator
    public IncidentCase(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations, 
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions,
            @JsonProperty("occurredAt") @BsonProperty("occurredAt") String occurredAt,
            @JsonProperty("location") @BsonProperty("location") Location location,
            @JsonProperty("seriousInjury") @BsonProperty("seriousInjury") boolean seriousInjury,
            @JsonProperty("crimeReference") @BsonProperty("crimeReference") String crimeReference,
            @JsonProperty("emergencyServices") @BsonProperty("emergencyServices") List<EmergencyServiceEnum> emergencyServices,
            @JsonProperty("policyHolderAtFault") @BsonProperty("policyHolderAtFault") AtFaultEnum policyHolderAtFault,
            @JsonProperty("contacts") @BsonProperty("contacts") List<Contact> contacts) { 
        super(id, createdAt, updatedAt, type, associations, module, notes, interactions);
        this.occurredAt = occurredAt;
        this.location = location;
        this.seriousInjury = seriousInjury;
        this.crimeReference = crimeReference;
        this.emergencyServices = emergencyServices;
        this.policyHolderAtFault = policyHolderAtFault;
        this.contacts = contacts;
    }

    @BsonCreator
    public IncidentCase() {
    }

    
    /**
     * @return the occurredAt
     */
    public String getOccurredAt() {
        return occurredAt;
    }

    
    /**
     * @param occurredAt the occurredAt to set
     */
    public void setOccurredAt(String occurredAt) {
        this.occurredAt = occurredAt;
    }

    
    /**
     * @return the location
     */
    public Location getLocation() {
        return location;
    }

    
    /**
     * @param location the location to set
     */
    public void setLocation(Location location) {
        this.location = location;
    }

    
    /**
     * @return the seriousInjury
     */
    public boolean isSeriousInjury() {
        return seriousInjury;
    }

    
    /**
     * @param seriousInjury the seriousInjury to set
     */
    public void setSeriousInjury(boolean seriousInjury) {
        this.seriousInjury = seriousInjury;
    }

    
    /**
     * @return the crimeReference
     */
    public String getCrimeReference() {
        return crimeReference;
    }

    
    /**
     * @param crimeReference the crimeReference to set
     */
    public void setCrimeReference(String crimeReference) {
        this.crimeReference = crimeReference;
    }

    
    /**
     * @return the emergencyServices
     */
    public List<EmergencyServiceEnum> getEmergencyServices() {
        return emergencyServices;
    }

    
    /**
     * @param emergencyServices the emergencyServices to set
     */
    public void setEmergencyServices(List<EmergencyServiceEnum> emergencyServices) {
        this.emergencyServices = emergencyServices;
    }

    
    /**
     * @return the policyHolderAtFault
     */
    public AtFaultEnum getPolicyHolderAtFault() {
        return policyHolderAtFault;
    }

    
    /**
     * @param policyHolderAtFault the policyHolderAtFault to set
     */
    public void setPolicyHolderAtFault(AtFaultEnum policyHolderAtFault) {
        this.policyHolderAtFault = policyHolderAtFault;
    }

    
    /**
     * @return the contacts
     */
    public List<Contact> getContacts() {
        return contacts;
    }

    
    /**
     * @param contacts the contacts to set
     */
    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " IncidentCase [occurredAt=" + occurredAt + ", location=" + location + ", seriousInjury=" + seriousInjury
                + ", crimeReference=" + crimeReference + ", emergencyServices=" + emergencyServices
                + ", policyHolderAtFault=" + policyHolderAtFault + ", contacts=" + contacts + "]";
    }

    

}
