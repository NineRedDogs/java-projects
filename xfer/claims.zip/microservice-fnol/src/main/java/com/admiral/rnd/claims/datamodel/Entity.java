package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Entity {

    @JsonProperty
    @BsonProperty
    private String id;


    @JsonProperty
    @BsonProperty
    private String createdAt;


    @JsonProperty
    @BsonProperty
    private String updatedAt;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     */
    @JsonCreator
    public Entity(@JsonProperty("id") @BsonProperty("id") String id, 
                  @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
                  @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt) {
        super();
        this.id = id;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    @BsonCreator
    public Entity() {
    }

    
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    
    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    
    /**
     * @return the createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    
    /**
     * @param createdAt the createdAt to set
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    
    /**
     * @return the updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    
    /**
     * @param updatedAt the updatedAt to set
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Entity [id=" + id + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + "]";
    }



}
