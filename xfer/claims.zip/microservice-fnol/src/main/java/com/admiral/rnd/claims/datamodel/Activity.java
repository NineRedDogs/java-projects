package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Activity extends Entity {

    @JsonProperty
    @BsonProperty
    private String caseId;

    @JsonProperty
    @BsonProperty
    private String name;

    @JsonProperty
    @BsonProperty
    private String data;

    @JsonProperty
    @BsonProperty
    private String text;

    @JsonProperty
    @BsonProperty
    private String owner;

    /**
     * @param caseId
     * @param name
     * @param data
     * @param text
     * @param owner
     */
    @JsonCreator
    public Activity(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("caseId") @BsonProperty("caseId") String caseId,
            @JsonProperty("name") @BsonProperty("name") String name, 
            @JsonProperty("data") @BsonProperty("data") String data, 
            @JsonProperty("text") @BsonProperty("text") String text,
            @JsonProperty("owner") @BsonProperty("owner") String owner) {
        super(id, createdAt, updatedAt);
        this.caseId = caseId;
        this.name = name;
        this.data = data;
        this.text = text;
        this.owner = owner;
    }

    @BsonCreator
    public Activity() {
    }

    
    /**
     * @return the caseId
     */
    public String getCaseId() {
        return caseId;
    }

    
    /**
     * @param caseId the caseId to set
     */
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    
    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    
    /**
     * @param data the data to set
     */
    public void setData(String data) {
        this.data = data;
    }

    
    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    
    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    
    /**
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    
    /**
     * @param owner the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Activity [caseId=" + caseId + ", name=" + name + ", data=" + data + ", text=" + text + ", owner="
                + owner + "]";
    }

}
