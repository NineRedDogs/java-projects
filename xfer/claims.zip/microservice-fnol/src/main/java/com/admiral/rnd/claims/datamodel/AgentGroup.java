package com.admiral.rnd.claims.datamodel;

import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AgentGroup extends Entity {

    @JsonProperty
    @BsonProperty
    private String name;


    @JsonProperty
    @BsonProperty
    private List<Agent> agents;


    /**
     * @param name
     * @param agents
     */
    @JsonCreator
    public AgentGroup(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("name") @BsonProperty("name") String name,
            @JsonProperty("agents") @BsonProperty("agents") List<Agent> agents) {
        super(id, createdAt, updatedAt);
        this.name = name;
        this.agents = agents;
    }

    @BsonCreator
    public AgentGroup() {
    }

    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    
    /**
     * @return the agents
     */
    public List<Agent> getAgents() {
        return agents;
    }

    
    /**
     * @param agents the agents to set
     */
    public void setAgents(List<Agent> agents) {
        this.agents = agents;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " AgentGroup [name=" + name + ", agents=" + agents + "]";
    }


}
