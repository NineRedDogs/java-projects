package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Error extends Entity {

    @JsonProperty
    @BsonProperty
    private int code;


    @JsonProperty
    @BsonProperty
    private String message;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param code
     * @param message
     */
    @JsonCreator
    public Error(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("code") @BsonProperty("code") int code,
            @JsonProperty("message") @BsonProperty("message") String message) {
        super(id, createdAt, updatedAt);
        this.code = code;
        this.message = message;
    }

    @BsonCreator
    public Error() {
    }

    
    /**
     * @return the code
     */
    public int getCode() {
        return code;
    }

    
    /**
     * @param code the code to set
     */
    public void setCode(int code) {
        this.code = code;
    }

    
    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    
    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Error [code=" + code + ", message=" + message + "]";
    }


}
