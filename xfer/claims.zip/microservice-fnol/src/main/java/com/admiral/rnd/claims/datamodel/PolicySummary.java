package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonDiscriminator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

@BsonDiscriminator
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")  
@JsonSubTypes({ @Type(value = CarPolicySummary.class, name = CarPolicySummary.TYPE_NAME), 
                @Type(value = HousePolicySummary.class, name = HousePolicySummary.TYPE_NAME) }) 
public abstract class PolicySummary extends Entity {

    @JsonProperty
    @BsonProperty
    private String policyNumber;

    @JsonProperty
    @BsonProperty
    private String startsOn;

    @JsonProperty
    @BsonProperty
    private String endsOn;

    @JsonProperty
    @BsonProperty
    private int noClaimsBonus;

    @JsonProperty
    @BsonProperty
    private String type;

    @JsonProperty
    @BsonProperty
    private List<Contact> policyHolders;

    @JsonProperty
    @BsonProperty
    private List<String> caseIds;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param type
     * @param policyNumber
     * @param startsOn
     * @param endsOn
     * @param noClaimsBonus
     * @param policyHolders
     * @param caseIds
     */
    @JsonCreator
    public PolicySummary(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type, 
            @JsonProperty("policyNumber") @BsonProperty("policyNumber") String policyNumber,
            @JsonProperty("startsOn") @BsonProperty("startsOn") String startsOn, 
            @JsonProperty("endsOn") @BsonProperty("endsOn") String endsOn,
            @JsonProperty("noClaimsBonus") @BsonProperty("noClaimsBonus") int noClaimsBonus,
            @JsonProperty("policyHolders") @BsonProperty("policyHolders") List<Contact> policyHolders,
            @JsonProperty("caseIds") @BsonProperty("caseIds") List<String> caseIds) {
        super(id, createdAt, updatedAt);
        this.type = type;
        this.policyNumber = policyNumber;
        this.startsOn = startsOn;
        this.endsOn = endsOn;
        this.noClaimsBonus = noClaimsBonus;
        this.policyHolders = policyHolders;
        this.caseIds = caseIds;
    }

    @BsonCreator
    public PolicySummary() {
    }

    
    /**
     * @return the policyNumber
     */
    public String getPolicyNumber() {
        return policyNumber;
    }

    
    /**
     * @param policyNumber the policyNumber to set
     */
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    
    /**
     * @return the startsOn
     */
    public String getStartsOn() {
        return startsOn;
    }

    
    /**
     * @param startsOn the startsOn to set
     */
    public void setStartsOn(String startsOn) {
        this.startsOn = startsOn;
    }

    
    /**
     * @return the endsOn
     */
    public String getEndsOn() {
        return endsOn;
    }

    
    /**
     * @param endsOn the endsOn to set
     */
    public void setEndsOn(String endsOn) {
        this.endsOn = endsOn;
    }

    
    /**
     * @return the noClaimsBonus
     */
    public int getNoClaimsBonus() {
        return noClaimsBonus;
    }

    
    /**
     * @param noClaimsBonus the noClaimsBonus to set
     */
    public void setNoClaimsBonus(int noClaimsBonus) {
        this.noClaimsBonus = noClaimsBonus;
    }

    
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    
    /**
     * @return the policyHolders
     */
    public List<Contact> getPolicyHolders() {
        return policyHolders;
    }

    
    /**
     * @param policyHolders the policyHolders to set
     */
    public void setPolicyHolders(List<Contact> policyHolders) {
        this.policyHolders = policyHolders;
    }

    
    /**
     * @return the caseIds
     */
    public List<String> getCaseIds() {
        return caseIds;
    }

    
    /**
     * @param caseIds the caseIds to set
     */
    public void setCaseIds(List<String> caseIds) {
        this.caseIds = caseIds;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " PolicySummary [policyNumber=" + policyNumber + ", startsOn=" + startsOn + ", endsOn=" + endsOn
                + ", noClaimsBonus=" + noClaimsBonus + ", type=" + type + ", policyHolders=" + policyHolders
                + ", caseIds=" + caseIds + "]";
    }

    

}
