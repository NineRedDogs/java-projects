package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class HouseClaimCase extends ClaimCase {
    
    protected static final String TYPE_NAME = "HouseClaimCase";
    
    @JsonProperty
    @BsonProperty
    private List<HouseLossEnum> losses;


    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param type
     * @param associations
     * @param module
     * @param notes
     * @param contacts
     * @param thirdParty
     * @param assessment
     * @param losses
     */
    @JsonCreator
    public HouseClaimCase(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations, 
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions,
            @JsonProperty("contacts") @BsonProperty("contacts") List<Contact> contacts,
            @JsonProperty("thirdParty") @BsonProperty("thirdParty") boolean thirdParty,
            @JsonProperty("assessment") @BsonProperty("assessment") LossAssessmentEnum assessment,
            @JsonProperty("losses") @BsonProperty("losses") List<HouseLossEnum> losses) {
        super(id, createdAt, updatedAt, type, associations, module, notes, interactions, contacts, thirdParty, assessment);
        this.losses = losses;
    }

    @BsonCreator
    public HouseClaimCase() {
    }

    
    /**
     * @return the losses
     */
    public List<HouseLossEnum> getLosses() {
        return losses;
    }

    
    /**
     * @param losses the losses to set
     */
    public void setLosses(List<HouseLossEnum> losses) {
        this.losses = losses;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " HouseClaimCase [losses=" + losses + "]";
    }


}
