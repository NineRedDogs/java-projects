package com.admiral.rnd.claims.messaging.consumer.carcase;

import java.util.Arrays;

import javax.inject.Singleton;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.TopicConsumer;

import io.micronaut.context.annotation.Property;

@Singleton
public class CaseConsumer extends TopicConsumer {

    public CaseConsumer(
                 @Property(name = "kafka.consumer.pollperiodms") long pollPeriodMs,
                 @Property(name = "kafka.bootstrap.servers") String brokers,
                 @Property(name = "kafka.cases.consumergroup") String groupId,
                 @Property(name = "kafka.cases.topicname") String topic,
                 @Property(name = "kafka.cases.num-handler-threads") int numThreads) {
        super(pollPeriodMs, Arrays.asList(topic), brokers, groupId, numThreads, "Case WS-RESPONSE consumer");
    }
    
    @Override
    protected Runnable newHandler(final ConsumerRecord<String, TopicRecord> record) {
        return new CaseRecordHandler(record, getCallback());
    }

}
