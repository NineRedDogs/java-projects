package com.admiral.rnd.claims.datamodel;

public enum HouseIncidentCategoryEnum {
    MALICIOUS_DAMAGE, FIRE, THEFT, FLOOD, OTHER
}
