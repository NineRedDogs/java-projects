package com.admiral.rnd.claims.db;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.in;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import javax.inject.Singleton;

import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.CarIncidentCase;
import com.admiral.rnd.claims.datamodel.CarPolicySummary;
import com.mongodb.client.model.ReplaceOptions;
import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import com.mongodb.reactivestreams.client.MongoCollection;

import io.micronaut.context.annotation.Property;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Single;

@Singleton
public class DbHelperCarCase {
    
    private static final Logger LOG = LoggerFactory.getLogger(DbHelperCarCase.class);
    
    private final MongoCollection<CarIncidentCase> caseCollection;
    private final MongoCollection<CarPolicySummary> policyCollection;
    
    /**
     * @param mongoClient
     */
    public DbHelperCarCase(
            @Property(name = "mongodb.db.cases.name") String casesDbName,
            @Property(name = "mongodb.db.cases.collection") String casesCollectionName,
            @Property(name = "mongodb.db.policies.name") String policiesDbName,
            @Property(name = "mongodb.db.policies.collection") String policiesCollectionName,
            MongoClient mongoClient) {
        
        final CodecRegistry pojoCodecRegistry = fromRegistries(
                MongoClients.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()) );
        
        // get case collection
        caseCollection = 
                mongoClient
                .getDatabase(casesDbName).withCodecRegistry(pojoCodecRegistry)
                .getCollection(casesCollectionName, CarIncidentCase.class);
        
        // get policy collection
        policyCollection = 
                mongoClient
                .getDatabase(policiesDbName).withCodecRegistry(pojoCodecRegistry)
                .getCollection(policiesCollectionName, CarPolicySummary.class);
    }

    public CarIncidentCase getCase(String interactionId) {
        LOG.info("looking up incident case [" + interactionId + "] from DB");
        Maybe<CarIncidentCase> dbSrchRes = Flowable.fromPublisher(
                caseCollection.find(in("interactions", interactionId)).limit(1)
                ).firstElement();
        return dbSrchRes.blockingGet();
    }

    public CarIncidentCase updateCase(CarIncidentCase ciCase) {
        final String caseId = ciCase.getId();
        Bson filter = eq("id", caseId);

        // if no entry for this policy number exists, create it 
        ReplaceOptions options = new ReplaceOptions().upsert(true);

        Single<CarIncidentCase> c = Single.fromPublisher(caseCollection.replaceOne(filter, ciCase, options)).map(success -> ciCase);
        return c.blockingGet();
    }

    public CarPolicySummary getPolicy(final String policyNum) {
        // look up policy from DB
        LOG.info("looking up policy [" + policyNum + "] from DB");
        Maybe<CarPolicySummary> pol = Flowable.fromPublisher(
                policyCollection.find(eq("policyNumber", policyNum)).limit(1)
                ).firstElement();
        CarPolicySummary px = pol.blockingGet();
        return px;
    }




}
