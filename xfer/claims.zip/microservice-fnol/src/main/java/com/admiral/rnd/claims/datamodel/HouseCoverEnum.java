package com.admiral.rnd.claims.datamodel;

public enum HouseCoverEnum {
    BUILDINGS, CONTENTS, BUILDINGS_AND_CONTENTS
}
