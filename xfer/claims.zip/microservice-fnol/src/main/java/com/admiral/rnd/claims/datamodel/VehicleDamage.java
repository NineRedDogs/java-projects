package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class VehicleDamage extends Entity {

    @JsonProperty
    @BsonProperty
    private DamageLocationEnum location;


    @JsonProperty
    @BsonProperty
    private DamageExtentEnum extent;


    @JsonProperty
    @BsonProperty
    private String description;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param location
     * @param extent
     * @param description
     */
    @JsonCreator
    public VehicleDamage(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("location") @BsonProperty("location") DamageLocationEnum location,
            @JsonProperty("extent") @BsonProperty("extent") DamageExtentEnum extent, 
            @JsonProperty("description") @BsonProperty("description") String description) {
        super(id, createdAt, updatedAt);
        this.location = location;
        this.extent = extent;
        this.description = description;
    }

    @BsonCreator
    public VehicleDamage() {
    }

    
    /**
     * @return the location
     */
    public DamageLocationEnum getLocation() {
        return location;
    }

    
    /**
     * @param location the location to set
     */
    public void setLocation(DamageLocationEnum location) {
        this.location = location;
    }

    
    /**
     * @return the extent
     */
    public DamageExtentEnum getExtent() {
        return extent;
    }

    
    /**
     * @param extent the extent to set
     */
    public void setExtent(DamageExtentEnum extent) {
        this.extent = extent;
    }

    
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " VehicleDamage [location=" + location + ", extent=" + extent + ", description=" + description + "]";
    }

    

}
