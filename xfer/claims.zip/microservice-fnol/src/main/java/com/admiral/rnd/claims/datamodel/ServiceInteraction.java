package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceInteraction extends Interaction {
    
    public static final String TYPE_NAME = "ServiceInteraction";

    @JsonProperty
    @BsonProperty
    private String serviceName;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param contactId
     * @param caseId
     * @param medium
     * @param verification
     * @param serviceName
     */
    @JsonCreator
    public ServiceInteraction(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("contactId") @BsonProperty("contactId") String contactId,
            @JsonProperty("caseId") @BsonProperty("caseId") String caseId, 
            @JsonProperty("medium") @BsonProperty("medium") InteractionMediumEnum medium,
            @JsonProperty("verification") @BsonProperty("verification") InteractionVerificationEnum verification,
            @JsonProperty("serviceName") @BsonProperty("serviceName") String serviceName) {
        super(id, createdAt, updatedAt, TYPE_NAME, contactId, caseId, medium, verification);
        this.serviceName = serviceName;
    }

    @BsonCreator
    public ServiceInteraction() {
    }

    
    /**
     * @return the serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    
    /**
     * @param serviceName the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " ServiceInteraction [serviceName=" + serviceName + "]";
    }



}
