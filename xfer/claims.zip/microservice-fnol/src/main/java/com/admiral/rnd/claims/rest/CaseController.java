package com.admiral.rnd.claims.rest;


import static com.mongodb.client.model.Filters.eq;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;

import com.admiral.rnd.claims.datamodel.Case;
import com.mongodb.client.model.ReplaceOneModel;
import com.mongodb.client.model.ReplaceOptions;
import com.mongodb.client.model.WriteModel;
import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import com.mongodb.reactivestreams.client.MongoCollection;

import io.micronaut.context.annotation.Property;
import io.micronaut.http.annotation.Controller;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Single;

@Controller("/cases")
public class CaseController implements CaseOperations<Case>{
    
    @Property(name = "mongodb.db.cases.name")
    private String dbName;
    
    @Property(name = "mongodb.db.cases.collection")
    private String collectionName;
    
    private final CodecRegistry pojoCodecRegistry;

    private MongoClient mongoClient;

    public CaseController(MongoClient mongoClient) {
        this.mongoClient = mongoClient;
        
        // create codec registry for POJOs - allows us to create pojos from mongodb/bson
        pojoCodecRegistry = fromRegistries(
                MongoClients.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()) );
    }

    private MongoCollection<Case> getCollection() {
        return mongoClient
                .getDatabase(dbName).withCodecRegistry(pojoCodecRegistry)
                .getCollection(collectionName, Case.class);
    }

    @Override
    public Single<List<Case>> list() {
        return Flowable.fromPublisher(
                getCollection()
                    .find()
        ).toList();
    }


    @Override
    public Maybe<Case> find(String caseId) {
        return Flowable.fromPublisher(
                getCollection()
                        .find(eq("id", caseId))
                        .limit(1)
        ).firstElement();
    }


    @Override
    public Single<Case> save(Case carCase) {
        final String caseId = carCase.getId();
        Bson filter = eq("id", caseId);
        
        // if no entry for this policy number exists, create it 
        ReplaceOptions options = new ReplaceOptions().upsert(true);
        
        return Single.fromPublisher(getCollection().replaceOne(filter, carCase, options)).map(success -> carCase);
    }

    @Override
    public Single<List<Case>> saveBulk(@Valid List<Case> kases) {

        List<WriteModel<Case>> updates = new ArrayList<WriteModel<Case>>();
        ReplaceOptions options = new ReplaceOptions().upsert(true);
        
        for (Case kase : kases) {
            updates.add(new ReplaceOneModel<Case>(eq("id", kase.getId()), kase, options));
        }
        
        // if no entry for this policy number exists, create it 
        return Single.fromPublisher(getCollection().bulkWrite(updates)).map(success -> kases);
    }

    @Override
    public void dropCollection() {
        getCollection().drop();
    }
    
    

}
