package com.admiral.rnd.claims.orchestrator.api;

/**
 * @author agrahame
 *
 */
public interface IOrchestrator {
    void start();
    void stop();
}
