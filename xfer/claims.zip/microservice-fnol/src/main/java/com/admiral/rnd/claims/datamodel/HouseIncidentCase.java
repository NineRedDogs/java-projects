package com.admiral.rnd.claims.datamodel;

import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class HouseIncidentCase extends IncidentCase {
    
    protected static final String TYPE_NAME = "HouseIncidentCase";

    @JsonProperty
    @BsonProperty
    private HousePolicySummary policy;


    @JsonProperty
    @BsonProperty
    private HouseIncidentCategoryEnum category;


    @JsonProperty
    @BsonProperty
    private boolean houseSecured;

    /**
     * @param policy
     * @param category
     * @param houseSecured
     */
    @JsonCreator
    public HouseIncidentCase(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations, 
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions,
            @JsonProperty("occurredAt") @BsonProperty("occurredAt") String occurredAt,
            @JsonProperty("location") @BsonProperty("location") Location location,
            @JsonProperty("seriousInjury") @BsonProperty("seriousInjury") boolean seriousInjury, 
            @JsonProperty("crimeReference") @BsonProperty("crimeReference") String crimeReference,
            @JsonProperty("emergencyServices") @BsonProperty("emergencyServices") List<EmergencyServiceEnum> emergencyServices,
            @JsonProperty("policyHolderAtFault") @BsonProperty("policyHolderAtFault") AtFaultEnum policyHolderAtFault,
            @JsonProperty("contacts") @BsonProperty("contacts") List<Contact> contacts, 
            @JsonProperty("policy") @BsonProperty("policy") HousePolicySummary policy,
            @JsonProperty("category") @BsonProperty("category") HouseIncidentCategoryEnum category,
            @JsonProperty("houseSecured") @BsonProperty("houseSecured") boolean houseSecured) {
        super(id, createdAt, updatedAt, type, associations, module, notes, interactions, occurredAt, location, seriousInjury, crimeReference, 
                emergencyServices, policyHolderAtFault, contacts);
        this.policy = policy;
        this.category = category;
        this.houseSecured = houseSecured;
    }

    @BsonCreator
    public HouseIncidentCase() {
    }

    
    /**
     * @return the policy
     */
    public HousePolicySummary getPolicy() {
        return policy;
    }

    
    /**
     * @param policy the policy to set
     */
    public void setPolicy(HousePolicySummary policy) {
        this.policy = policy;
    }

    
    /**
     * @return the category
     */
    public HouseIncidentCategoryEnum getCategory() {
        return category;
    }

    
    /**
     * @param category the category to set
     */
    public void setCategory(HouseIncidentCategoryEnum category) {
        this.category = category;
    }

    
    /**
     * @return the houseSecured
     */
    public boolean isHouseSecured() {
        return houseSecured;
    }

    
    /**
     * @param houseSecured the houseSecured to set
     */
    public void setHouseSecured(boolean houseSecured) {
        this.houseSecured = houseSecured;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " HouseIncidentCase [policy=" + policy + ", category=" + category + ", houseSecured=" + houseSecured
                + "]";
    }


}
