package com.admiral.rnd.claims.messaging.consumer.interaction;

import java.util.Arrays;

import javax.inject.Singleton;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.db.DbHelperCarCase;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.TopicConsumer;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;

import io.micronaut.context.annotation.Property;


@Singleton
public class InteractionConsumer extends TopicConsumer {
    private static final Logger LOG = LoggerFactory.getLogger(InteractionConsumer.class);
    
    private final DbHelperCarCase dbAccessor;
    private final ICaseProducer caseProducer;

    public InteractionConsumer(
            @Property(name = "kafka.consumer.pollperiodms") long pollPeriodMs,
            @Property(name = "kafka.bootstrap.servers") String brokers,
            @Property(name = "kafka.interactions.consumergroup") String groupId,
            @Property(name = "kafka.interactions.topicname") String topic,
            @Property(name = "kafka.interactions.num-handler-threads") int numThreads,
            DbHelperCarCase dbAccessor,
            ICaseProducer caseProducer) {
        super(pollPeriodMs, Arrays.asList(topic), brokers, groupId, numThreads, "Interaction consumer");
        this.dbAccessor = dbAccessor;
        this.caseProducer = caseProducer;
        LOG.debug("InteractionConsumer ctor");
    }

    @Override
    protected Runnable newHandler(final ConsumerRecord<String, TopicRecord> record) {
        return new InteractionRecordHandler(record, dbAccessor, caseProducer);
    }


}
