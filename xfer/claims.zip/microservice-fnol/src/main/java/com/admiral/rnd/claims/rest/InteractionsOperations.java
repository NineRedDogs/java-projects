package com.admiral.rnd.claims.rest;

import java.util.List;

import javax.validation.Valid;

import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Delete;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.reactivex.Maybe;
import io.reactivex.Single;

public interface InteractionsOperations<T> {

    @Get("/")
    Single<List<T>> list();

    @Get("/{interactionId}")
    Maybe<T> find(String interactionId);

    @Post("/")
    Single<T> save(@Valid @Body T interaction);
    
    @Delete("/")
    void dropDB();
    

}
