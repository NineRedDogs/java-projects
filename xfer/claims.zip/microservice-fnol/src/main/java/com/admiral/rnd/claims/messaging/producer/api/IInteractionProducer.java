package com.admiral.rnd.claims.messaging.producer.api;

public interface IInteractionProducer extends IClaimsProducer {
    
    // No extra methods needed above IClaimsProducer - just need a specialised interface to help inject an InteractionProducer object - 
    // as there may be two variants of IClaimsProducer objects being injected into some classes - just want to give micronaut a helping
    // hand as to which injection will be required.

}
