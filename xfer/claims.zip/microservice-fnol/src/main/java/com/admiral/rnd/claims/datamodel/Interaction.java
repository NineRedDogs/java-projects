package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonDiscriminator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

@BsonDiscriminator
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")  
@JsonSubTypes({ @Type(value = AgentInteraction.class, name = AgentInteraction.TYPE_NAME), 
                @Type(value = ServiceInteraction.class, name = ServiceInteraction.TYPE_NAME) }) 
public abstract class Interaction extends Entity {

    @JsonProperty
    @BsonProperty
    private String contactId;


    @JsonProperty
    @BsonProperty
    private String caseId;


    @JsonProperty
    @BsonProperty
    private InteractionMediumEnum medium;

    @JsonProperty
    @BsonProperty
    private String type;


    @JsonProperty
    @BsonProperty
    private InteractionVerificationEnum verification;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param contactId
     * @param caseId
     * @param medium
     * @param verification
     */
    @JsonCreator
    public Interaction(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type, 
            @JsonProperty("contactId") @BsonProperty("contactId") String contactId,
            @JsonProperty("caseId") @BsonProperty("caseId") String caseId, 
            @JsonProperty("medium") @BsonProperty("medium") InteractionMediumEnum medium,
            @JsonProperty("verification") @BsonProperty("verification") InteractionVerificationEnum verification) {
        super(id, createdAt, updatedAt);
        this.type = type;
        this.contactId = contactId;
        this.caseId = caseId;
        this.medium = medium;
        this.verification = verification;
    }

    @BsonCreator
    public Interaction() {
    }

    
    /**
     * @return the contactId
     */
    public String getContactId() {
        return contactId;
    }

    
    /**
     * @param contactId the contactId to set
     */
    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    
    /**
     * @return the caseId
     */
    public String getCaseId() {
        return caseId;
    }

    
    /**
     * @param caseId the caseId to set
     */
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    
    /**
     * @return the medium
     */
    public InteractionMediumEnum getMedium() {
        return medium;
    }

    
    /**
     * @param medium the medium to set
     */
    public void setMedium(InteractionMediumEnum medium) {
        this.medium = medium;
    }

    
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    
    /**
     * @return the verification
     */
    public InteractionVerificationEnum getVerification() {
        return verification;
    }

    
    /**
     * @param verification the verification to set
     */
    public void setVerification(InteractionVerificationEnum verification) {
        this.verification = verification;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Interaction [contactId=" + contactId + ", caseId=" + caseId + ", medium=" + medium + ", type=" + type
                + ", verification=" + verification + "]";
    }

    
}
