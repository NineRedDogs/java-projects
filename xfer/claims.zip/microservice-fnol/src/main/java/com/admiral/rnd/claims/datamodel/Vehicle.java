package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Vehicle extends Entity {

    @JsonProperty
    @BsonProperty
    private String make;


    @JsonProperty
    @BsonProperty
    private String model;


    @JsonProperty
    @BsonProperty
    private String color;


    @JsonProperty
    @BsonProperty
    private List<String> modifications;


    @JsonProperty
    @BsonProperty
    private String registration;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param make
     * @param model
     * @param color
     * @param modifications
     * @param registration
     */
    @JsonCreator
    public Vehicle(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("make") @BsonProperty("make") String make,
            @JsonProperty("model") @BsonProperty("model") String model, 
            @JsonProperty("color") @BsonProperty("color") String color,
            @JsonProperty("modifications") @BsonProperty("modifications") List<String> modifications,
            @JsonProperty("registration") @BsonProperty("registration") String registration) {
        super(id, createdAt, updatedAt);
        this.make = make;
        this.model = model;
        this.color = color;
        this.modifications = modifications;
        this.registration = registration;
    }

    @BsonCreator
    public Vehicle() {
    }

    
    /**
     * @return the make
     */
    public String getMake() {
        return make;
    }

    
    /**
     * @param make the make to set
     */
    public void setMake(String make) {
        this.make = make;
    }

    
    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    
    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }

    
    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    
    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    
    /**
     * @return the modifications
     */
    public List<String> getModifications() {
        return modifications;
    }

    
    /**
     * @param modifications the modifications to set
     */
    public void setModifications(List<String> modifications) {
        this.modifications = modifications;
    }

    
    /**
     * @return the registration
     */
    public String getRegistration() {
        return registration;
    }

    
    /**
     * @param registration the registration to set
     */
    public void setRegistration(String registration) {
        this.registration = registration;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Vehicle [make=" + make + ", model=" + model + ", color=" + color + ", modifications=" + modifications
                + ", registration=" + registration + "]";
    }


}
