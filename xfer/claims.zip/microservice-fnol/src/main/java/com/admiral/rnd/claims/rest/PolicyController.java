package com.admiral.rnd.claims.rest;


import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import com.admiral.rnd.claims.datamodel.PolicySummary;
import com.mongodb.client.model.ReplaceOneModel;
import com.mongodb.client.model.ReplaceOptions;
import com.mongodb.client.model.WriteModel;
import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoCollection;

import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.micronaut.context.annotation.Property;
import io.micronaut.http.annotation.Controller;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Single;

@Controller("/policies")
public class PolicyController implements PolicyOperations<PolicySummary>{
    
    private static final Logger LOG = LoggerFactory.getLogger(PolicyController.class);

    @Property(name = "mongodb.db.policies.name")
    private String dbName;
    
    @Property(name = "mongodb.db.policies.collection")
    private String collectionName;

    private MongoClient mongoClient;

    public PolicyController(
            MongoClient mongoClient) {
        this.mongoClient = mongoClient;
        LOG.error("AJG: PolicyController.ctor called");
    }


    private MongoCollection<PolicySummary> getCollection() {
        LOG.error("AJG: PolicyController.get called");

        return mongoClient
                .getDatabase(dbName)
                .getCollection(collectionName, PolicySummary.class);
    }


    @Override
    public Single<List<PolicySummary>> list() {
        LOG.error("AJG: PolicyController.list called");
        return Flowable.fromPublisher(
                getCollection()
                    .find()
        ).toList();
    }


    @Override
    public Maybe<PolicySummary> find(String policyNum) {
        
        return Flowable.fromPublisher(
                getCollection()
                        .find(eq("policyNumber", policyNum))
                        .limit(1)
        ).firstElement();
    }


    @Override
    public Single<PolicySummary> save(@Valid PolicySummary policy) {
        final String policyNum = policy.getPolicyNumber();
        Bson filter = eq("policyNumber", policyNum);
        
        // if no entry for this policy number exists, create it 
        ReplaceOptions options = new ReplaceOptions().upsert(true);
        
        return Single.fromPublisher(getCollection().replaceOne(filter, policy, options)).map(success -> policy);
    }
    
    @Override
    public Single<List<PolicySummary>> saveBulk(@Valid List<PolicySummary> policies) {

        List<WriteModel<PolicySummary>> updates = new ArrayList<WriteModel<PolicySummary>>();
        ReplaceOptions options = new ReplaceOptions().upsert(true);
        
        for (PolicySummary policy : policies) {
            updates.add(new ReplaceOneModel<PolicySummary>(eq("id", policy.getId()), policy, options));
        }
        
        // if no entry for this policy number exists, create it 
        return Single.fromPublisher(getCollection().bulkWrite(updates)).map(success -> policies);
    }



}
