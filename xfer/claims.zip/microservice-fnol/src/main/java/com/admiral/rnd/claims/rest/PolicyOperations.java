package com.admiral.rnd.claims.rest;

import java.util.List;

import javax.validation.Valid;

import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.reactivex.Maybe;
import io.reactivex.Single;

public interface PolicyOperations<T> {

    @Get("/")
    Single<List<T>> list();

    @Get("/{policyNum}")
    Maybe<T> find(String policyNum);

    @Post("/")
    Single<T> save(@Valid @Body T policy);
    
    @Post("/bulk")
    Single<List<T>> saveBulk(@Valid @Body List<T> policies);

}
