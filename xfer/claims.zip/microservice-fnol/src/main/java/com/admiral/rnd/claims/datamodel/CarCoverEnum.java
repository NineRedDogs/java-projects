package com.admiral.rnd.claims.datamodel;

public enum CarCoverEnum {
    COMPREHENSIVE, THIRD_PARTY, THIRD_PARTY_FIRE_AND_THEFT
}
