package com.admiral.rnd.claims.datamodel;

public enum LossAssessmentEnum {
    TOTAL_LOSS, MAJOR_LOSS, MINOR_LOSS
}
