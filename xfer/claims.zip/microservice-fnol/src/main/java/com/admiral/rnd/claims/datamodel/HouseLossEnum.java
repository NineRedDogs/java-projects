package com.admiral.rnd.claims.datamodel;

public enum HouseLossEnum {
    BUILDING, CONTENTS
}
