package com.admiral.rnd.claims.datamodel;

public enum AtFaultEnum {
    YES, NO, PARTIAL, UNSURE
}
