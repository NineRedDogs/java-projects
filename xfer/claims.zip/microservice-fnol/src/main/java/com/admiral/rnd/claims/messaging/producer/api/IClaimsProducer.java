package com.admiral.rnd.claims.messaging.producer.api;

import com.admiral.rnd.claims.messaging.TopicRecord;


public interface IClaimsProducer {

    void postEvent(String key, TopicRecord wsCaseRequest);

}
