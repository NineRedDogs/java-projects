package com.admiral.rnd.claims.orchestrator.exceptions;


public class IllegalTransitionException extends Exception {

    private static final long serialVersionUID = 1L;

    public IllegalTransitionException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public IllegalTransitionException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
        super(arg0, arg1, arg2, arg3);
    }

    public IllegalTransitionException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    public IllegalTransitionException(String arg0) {
        super(arg0);
    }

    public IllegalTransitionException(Throwable arg0) {
        super(arg0);
    }
    
    

}
