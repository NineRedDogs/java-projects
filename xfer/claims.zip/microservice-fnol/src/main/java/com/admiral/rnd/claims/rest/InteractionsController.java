package com.admiral.rnd.claims.rest;


import static com.mongodb.client.model.Filters.eq;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

import java.util.List;

import javax.inject.Inject;

import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.events.Event;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.producer.api.IInteractionProducer;
import com.admiral.rnd.claims.orchestrator.api.IOrchestrator;
import com.admiral.rnd.claims.orchestrator.exceptions.IllegalTransitionException;
import com.admiral.rnd.claims.rest.selfservice.IInteractions;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mongodb.client.model.ReplaceOptions;
import com.mongodb.reactivestreams.client.MongoClient;
import com.mongodb.reactivestreams.client.MongoClients;
import com.mongodb.reactivestreams.client.MongoCollection;

import io.micronaut.context.annotation.Property;
import io.micronaut.http.annotation.Controller;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.reactivex.Single;


@Controller("/interactions")
public class InteractionsController implements InteractionsOperations<Event> {
    private static final Logger LOG = LoggerFactory.getLogger(InteractionsController.class);
    
    @Property(name = "mongodb.db.interactions.name")
    private String dbName;
    
    @Property(name = "mongodb.db.interactions.collection")
    private String collectionName;
    
    private final MongoClient mongoClient;
    private final IInteractions interactions;
    private final IInteractionProducer interactionProducer;
    private final IOrchestrator orchestrator;
    
    private final CodecRegistry pojoCodecRegistry;

    @Inject
    public InteractionsController(
            final MongoClient mongoClient, 
            final IInteractionProducer interactionProducer, 
            final IInteractions interactions,
            final IOrchestrator orchestrator) {
        this.mongoClient = mongoClient;
        this.interactionProducer = interactionProducer;
        this.interactions = interactions;
        this.orchestrator = orchestrator;
        
        this.orchestrator.start();
        
        // create codec registry for POJOs - allows us to create pojos from mongodb/bson
        pojoCodecRegistry = fromRegistries(
                MongoClients.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()) );
    }

    private MongoCollection<Event> getCollection() {
        return mongoClient
                .getDatabase(dbName).withCodecRegistry(pojoCodecRegistry)
                .getCollection(collectionName, Event.class);
    }

    @Override
    public Single<List<Event>> list() {
        return Flowable.fromPublisher(
                getCollection()
                    .find()
        ).toList();
    }

    @Override
    public Maybe<Event> find(String interactionId) {
        return Flowable.fromPublisher(
                getCollection()
                        .find(eq("id", interactionId))
                        .limit(1)
        ).firstElement();
    }


    @Override
    public Single<Event> save(Event interaction) {

        // eventually - refactor the following aggregator code into its own module
        
        LOG.info("received interaction [" + interaction + "]");

        // extract interaction id
        final String interactionId = interaction.getId();
        
        // 1. for housekeeping purposes, save event to mongo DB
        Bson filter = eq("id", interactionId);

        // if no entry for this policy number exists, create it 
        ReplaceOptions options = new ReplaceOptions().upsert(true);

        Single<Event> savedEvent = Single.fromPublisher(
                getCollection().replaceOne(filter, interaction, options)).map(success -> interaction);

        
        // 2. Transition Self-Service interaction ...
        try {
            interactions.transitionInteraction(interaction);

            //
            // valid self service event received, so can now proceed.
            //
            // 3. post event to topic
            try {
                interactionProducer.postEvent(interactionId, new TopicRecord(interactionId, interaction.asJson()));
            } catch (JsonProcessingException e) {
                LOG.info("Error parsing to JSON, e:" + e.getClass().getName() + " - " + e.getMessage());
            }
            return savedEvent;
        } catch (IllegalTransitionException e) {
            return Single.error(e);
        } 
        
        // 2. save event to mongo DB
        //Bson filter = eq("id", interactionId);

        // if no entry for this policy number exists, create it 
        //ReplaceOptions options = new ReplaceOptions().upsert(true);

        //return savedEvent;
    }

    
    @Override
    public void dropDB() {
        LOG.info("AJG ------ dropping Interaction DB ");
        mongoClient.getDatabase(dbName).drop();
        
        //Publisher<Success> publisher = getCollection().drop();
        
        
        
    }
    

}
