package com.admiral.rnd.claims.datamodel;

public enum PhoneTypeEnum {
    PRIMARY, SECONDARY, MOBILE, HOME, WORK, THIRD_PARTY
}
