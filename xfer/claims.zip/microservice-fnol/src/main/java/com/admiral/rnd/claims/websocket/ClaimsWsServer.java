package com.admiral.rnd.claims.websocket;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.WsCallback;
import com.admiral.rnd.claims.datamodel.Case;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.carcase.CaseConsumer;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.micronaut.context.annotation.Property;
import io.micronaut.websocket.WebSocketBroadcaster;
import io.micronaut.websocket.WebSocketSession;
import io.micronaut.websocket.annotation.OnClose;
import io.micronaut.websocket.annotation.OnMessage;
import io.micronaut.websocket.annotation.OnOpen;
import io.micronaut.websocket.annotation.ServerWebSocket;

@ServerWebSocket("/claims/{caseId}")
public class ClaimsWsServer implements WsCallback {
    private static final Logger LOG = LoggerFactory.getLogger(ClaimsWsServer.class);
    
    @Inject
    private ICaseProducer caseProducer;

    private final WebSocketBroadcaster broadcaster;
    private final CaseConsumer respConsumer;


    private String caseId;
    private WebSocketSession session;

    @Property(name = "kafka.bootstrap.servers")
    String kafkaServers;

    /**
     * Constructor.
     * 
     * @param broadcaster
     */
    public ClaimsWsServer(WebSocketBroadcaster broadcaster,
            CaseConsumer respConsumer) {
        this.broadcaster = broadcaster;
        this.respConsumer = respConsumer;
    }

    private void out(final String msg) {
        //LOG.info("Claims WS Socket:: " + msg);
        LOG.error("Claims WS Socket:: " + msg);
    }

    protected String getCaseId() {
        return caseId;
    }

    protected String getSessionId() {
        return session.getId();
    }

    @OnOpen
    public void onOpen(String caseId, WebSocketSession session) {
        this.caseId = caseId;
        this.session = session;
        String msg = "case [" + caseId + "] opened !";
        out("onOpen(): " + msg);
        setUpResponseHandler();
    }

    @OnMessage
    public void onMessage(
            String caseId,
            String caseEvent,
            WebSocketSession session) {

        if (messageParamsOk(caseId, session.getId())) {
            // add event to topic
            caseProducer.postEvent(caseId, new TopicRecord(session.getId(), caseEvent));

        } else {
            out("Unexpected case Id and/or session id ... not adding to case topic .... ");
        }
    }

    private boolean messageParamsOk(String caseId, String wsSessionId) {
        return (this.getCaseId().equalsIgnoreCase(caseId) &&
                this.getSessionId().equalsIgnoreCase(wsSessionId));
    }

    @OnClose
    public void onClose(
            String caseId,
            WebSocketSession session) {
        String msg = "case [" + caseId + "] closed !";
        out("onClose(): " + msg);
    }

    /**
     * 
     * Heres an example of a method that returns a message to be broadcasted 
     * 
    @OnClose
    public Publisher<String> onClose(
            String caseId,
            WebSocketSession session) {
        String msg = "case [" + caseId + "] closed !";
        out("onClose(): " + msg);

        return session.sendAsync("xyz", isValid(response.get_id(), session));
        
        or if want to broadcast to multiple ws connections :
        
        return broadcaster.broadcast("xyz", isValid(response.get_id(), session));
    } */

    private void setUpResponseHandler() {
        Thread thread = new Thread(respConsumer);
        thread.start();
        out("setUpResponseHandler (started)");
    }

    @Override
    public void caseToReturn(Case response, String caseId, String wsSessionId) {
        ObjectMapper mapper = new ObjectMapper();
        String respJson="{}";
        try {
            respJson = mapper.writeValueAsString(response);
        } catch (JsonProcessingException e) {
            out("Caught JsonProcessingException when serializing WS Response JSON object, e:" 
                    + e.getMessage());
        }
        out("send response back over ws [" + respJson + "]");

        
        if (wsSessionId.equalsIgnoreCase(session.getId())) {
            // need to make sure this message only goes over the ws connection we want it to
            session.sendAsync(respJson);

            // however if want to broadcast message over multiple web sockets - can use broadcast with 
            // predicate filter ...
            //
            // broadcaster.broadcastAsync(respJson, isValid(response.get_id(), session));
        } else {
            out("Mismatch with sessions, did not send over WS !!");
        }
    }
    
    /**
    private Predicate<WebSocketSession> isValid(String caseId, WebSocketSession session) {
        return s -> s == session && caseId.equalsIgnoreCase(s.getUriVariables().get("caseId", String.class, null));
    }
     */

    public WebSocketBroadcaster getBroadcaster() {
        return broadcaster;
    }



}
