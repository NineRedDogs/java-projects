package com.admiral.rnd.claims.datamodel;

public enum CarLossEnum {
    VEHICLE, PROPERTY, PERSONAL_INJURY
}
