package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Agent extends Entity {

    @JsonProperty
    @BsonProperty
    private String firstName;


    @JsonProperty
    @BsonProperty
    private String lastName;


    @JsonProperty
    @BsonProperty
    private String email;


    @JsonProperty
    @BsonProperty
    private String passwordHash;

    /**
     * @param firstName
     * @param lastName
     * @param email
     * @param passwordHash
     */
    @JsonCreator
    public Agent(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("firstName") @BsonProperty("firstName") String firstName,
            @JsonProperty("lastName") @BsonProperty("lastName") String lastName, 
            @JsonProperty("email") @BsonProperty("email") String email,
            @JsonProperty("passwordHash") @BsonProperty("passwordHash") String passwordHash) {
        super(id, createdAt, updatedAt);
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.passwordHash = passwordHash;
    }

    @BsonCreator
    public Agent() {
    }

    
    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    
    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    
    /**
     * @return the passwordHash
     */
    public String getPasswordHash() {
        return passwordHash;
    }

    
    /**
     * @param passwordHash the passwordHash to set
     */
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Agent [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", passwordHash="
                + passwordHash + "]";
    }


}
