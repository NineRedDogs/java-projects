package com.admiral.rnd.claims.rest.selfservice;

import com.admiral.rnd.claims.datamodel.events.Event;
import com.admiral.rnd.claims.orchestrator.exceptions.IllegalTransitionException;


public interface IInteractions {

    void transitionInteraction(Event event) throws IllegalTransitionException;

}
