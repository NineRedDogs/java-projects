package com.admiral.rnd.claims.messaging.consumer.selfservice;

import java.util.Arrays;

import javax.inject.Singleton;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.TopicConsumer;

import io.micronaut.context.annotation.Property;


@Singleton
public class SelfServiceConsumer extends TopicConsumer {

    public SelfServiceConsumer(
            @Property(name = "kafka.consumer.pollperiodms") long pollPeriodMs,
            @Property(name = "kafka.bootstrap.servers") String brokers,
            @Property(name = "kafka.selfservice.consumergroup") String groupId,
            @Property(name = "kafka.selfservice.topicname") String topic,
            @Property(name = "kafka.selfservice.num-handler-threads") int numThreads) {
        super(pollPeriodMs, Arrays.asList(topic), brokers, groupId, numThreads, "Self Service consumer");
    }

    @Override
    protected Runnable newHandler(final ConsumerRecord<String, TopicRecord> record) {
        return new SelfServiceRecordHandler(record);
    }

}
