package com.admiral.rnd.claims.datamodel;

import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class HousePolicySummary extends PolicySummary {
    
    public static final String TYPE_NAME = "HousePolicySummary";

    @JsonProperty
    @BsonProperty
    private HouseCoverEnum cover;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param policyNumber
     * @param startsOn
     * @param endsOn
     * @param noClaimsBonus
     * @param policyHolders
     * @param caseIds
     * @param cover
     */
    @JsonCreator
    public HousePolicySummary(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("policyNumber") @BsonProperty("policyNumber") String policyNumber,
            @JsonProperty("startsOn") @BsonProperty("startsOn") String startsOn, 
            @JsonProperty("endsOn") @BsonProperty("endsOn") String endsOn,
            @JsonProperty("noClaimsBonus") @BsonProperty("noClaimsBonus") int noClaimsBonus,
            @JsonProperty("policyHolders") @BsonProperty("policyHolders") List<Contact> policyHolders, 
            @JsonProperty("caseIds") @BsonProperty("caseIds") List<String> caseIds,
            @JsonProperty("cover") @BsonProperty("cover") HouseCoverEnum cover) {
        super(id, createdAt, updatedAt, TYPE_NAME, policyNumber, startsOn, endsOn, noClaimsBonus, policyHolders, caseIds);
        this.cover = cover;
    }

    @BsonCreator
    public HousePolicySummary() {
    }

    
    /**
     * @return the cover
     */
    public HouseCoverEnum getCover() {
        return cover;
    }

    
    /**
     * @param cover the cover to set
     */
    public void setCover(HouseCoverEnum cover) {
        this.cover = cover;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " HousePolicySummary [cover=" + cover + "]";
    }



}
