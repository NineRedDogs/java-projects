package com.admiral.rnd.claims.datamodel;

public enum DamageExtentEnum {
    SUPERFICIAL, MINOR, MAJOR
}
