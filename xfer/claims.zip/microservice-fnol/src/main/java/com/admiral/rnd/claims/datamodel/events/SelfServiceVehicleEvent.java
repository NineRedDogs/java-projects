package com.admiral.rnd.claims.datamodel.events;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.admiral.rnd.claims.datamodel.CarIncidentCase;
import com.admiral.rnd.claims.datamodel.Contact;
import com.admiral.rnd.claims.datamodel.Location;
import com.admiral.rnd.claims.datamodel.Vehicle;
import com.admiral.rnd.claims.db.DbHelperCarCase;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SelfServiceVehicleEvent extends Event {
    
    // ss3
    protected static final String EVENT_NAME = "SelfServiceVehicleEvent";
    
    private static final List<Class<?>> validTransitions = Collections.unmodifiableList(Arrays.asList(
            SelfServiceVehicleEvent.class));

    @JsonProperty
    @BsonProperty
    private boolean thirdParty;
    
    @JsonProperty
    @BsonProperty
    private Vehicle vehicle;
    
    @JsonProperty
    @BsonProperty
    private Contact driver;
    
    @JsonProperty
    @BsonProperty
    private List<Contact> passengers;
    
    @JsonProperty
    @BsonProperty
    private boolean primaryContactIsDriver;

    @JsonProperty
    @BsonProperty
    private Location recoveryLocation;
    
    
    /**
     * @param id
     * @param interactionId
     * @param name
     * @param thirdParty
     * @param vehicle
     * @param driver
     * @param passengers
     * @param primaryContactIsDriver
     * @param recoveryLocation
     */
    @JsonCreator
    public SelfServiceVehicleEvent(
            @JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("interactionId") @BsonProperty("interactionId") String interactionId, 
            @JsonProperty("thirdParty") @BsonProperty("thirdParty") boolean thirdParty, 
            @JsonProperty("vehicle") @BsonProperty("vehicle") Vehicle vehicle,
            @JsonProperty("driver") @BsonProperty("driver") Contact driver, 
            @JsonProperty("passengers") @BsonProperty("passengers") List<Contact> passengers, 
            @JsonProperty("primaryContactIsDriver") @BsonProperty("primaryContactIsDriver") boolean primaryContactIsDriver, 
            @JsonProperty("recoveryLocation") @BsonProperty("recoveryLocation") Location recoveryLocation) {
        super(id, interactionId, EVENT_NAME);
        this.thirdParty = thirdParty;
        this.vehicle = vehicle;
        this.driver = driver;
        this.passengers = passengers;
        this.primaryContactIsDriver = primaryContactIsDriver;
        this.recoveryLocation = recoveryLocation;
    }

    @BsonCreator
    public SelfServiceVehicleEvent() {}
    
    /**
     * @return the thirdParty
     */
    public boolean isThirdParty() {
        return thirdParty;
    }
    
    /**
     * @param thirdParty the thirdParty to set
     */
    public void setThirdParty(boolean thirdParty) {
        this.thirdParty = thirdParty;
    }
    
    /**
     * @return the vehicle
     */
    public Vehicle getVehicle() {
        return vehicle;
    }
    
    /**
     * @param vehicle the vehicle to set
     */
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    
    /**
     * @return the driver
     */
    public Contact getDriver() {
        return driver;
    }
    
    /**
     * @param driver the driver to set
     */
    public void setDriver(Contact driver) {
        this.driver = driver;
    }
    
    /**
     * @return the passengers
     */
    public List<Contact> getPassengers() {
        return passengers;
    }
    
    /**
     * @param passengers the passengers to set
     */
    public void setPassengers(List<Contact> passengers) {
        this.passengers = passengers;
    }
    
    /**
     * @return the primaryContactIsDriver
     */
    public boolean isPrimaryContactIsDriver() {
        return primaryContactIsDriver;
    }
    
    /**
     * @param primaryContactIsDriver the primaryContactIsDriver to set
     */
    public void setPrimaryContactIsDriver(boolean primaryContactIsDriver) {
        this.primaryContactIsDriver = primaryContactIsDriver;
    }
    
    /**
     * @return the recoveryLocation
     */
    public Location getRecoveryLocation() {
        return recoveryLocation;
    }
    
    /**
     * @param recoveryLocation the recoveryLocation to set
     */
    public void setRecoveryLocation(Location recoveryLocation) {
        this.recoveryLocation = recoveryLocation;
    }
    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " SelfServiceVehicleEvent [thirdParty=" + thirdParty + ", vehicle=" + vehicle
                + ", driver=" + driver + ", passengers=" + passengers + ", primaryContactIsDriver="
                + primaryContactIsDriver + ", recoveryLocation=" + recoveryLocation + "]";
    }

    @Override
    protected List<Class<?>> getValidTransitions() {
        return validTransitions;
    }

    @Override
    public void addSelfServiceEventData(final CarIncidentCase ciCase, DbHelperCarCase dbAccessor) {
        super.addSelfServiceEventData(ciCase, dbAccessor);

        // now set the new CarIncidentCase instance properties with those of this SelfServiceEvent
        
        // TODO fields from this SS event need to be correctly added, just done some arbitrary fields to 
        // show updates have been done .... will need to be completed ...
        
        // add all person's attached to the vehicle as contacts to the case
        if (getDriver() != null) {
            ciCase.getContacts().add(getDriver());
        }
        if (getPassengers() != null) {
            for (Contact passenger : getPassengers()) {
                ciCase.getContacts().add(passenger);
            }
        }
        ciCase.setRecoveryLocation(getRecoveryLocation());
    }

}
