package com.admiral.rnd.claims.messaging.producer;

import javax.inject.Singleton;

import com.admiral.rnd.claims.messaging.producer.api.IInteractionProducer;

import io.micronaut.context.annotation.Property;

@Singleton
public class InteractionProducer extends ClaimsProducer implements IInteractionProducer {

    public InteractionProducer(@Property(name = "kafka.bootstrap.servers") String servers,
                               @Property(name = "kafka.interactions.topicname") String topic) {
        super(servers, topic);
    }
    
}
