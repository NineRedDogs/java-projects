package com.admiral.rnd.claims.orchestrator;

import javax.inject.Singleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.messaging.consumer.interaction.InteractionConsumer;
import com.admiral.rnd.claims.messaging.consumer.selfservice.SelfServiceConsumer;
import com.admiral.rnd.claims.orchestrator.api.IOrchestrator;

@Singleton
public class Orchestrator implements IOrchestrator {

    private static final Logger LOG = LoggerFactory.getLogger(Orchestrator.class);
    
    private final InteractionConsumer interactionConsumer; 
    private final SelfServiceConsumer selfServiceConsumer; 

    public Orchestrator(InteractionConsumer interactionConsumer, SelfServiceConsumer selfServiceConsumer) {
        LOG.debug("AJG: (D) Orchestrator: CTOR() ...");
        LOG.error("AJG: (E) Orchestrator: CTOR() ...");
        this.interactionConsumer = interactionConsumer;
        this.selfServiceConsumer = selfServiceConsumer;
    }

    /* (non-Javadoc)
     * @see com.admiral.rnd.claims.orchestrator.IOrchestrator#start()
     */
    @Override
    public void start() {
        LOG.debug("Orchestrator: start() ...");
        // Start up consumer threads ...
        
        // interaction request consumer
        final Thread interactionConsumerT = new Thread(interactionConsumer);
        interactionConsumerT.start();

        // self service request consumer
        final Thread selfServiceConsumerT = new Thread(selfServiceConsumer);
        selfServiceConsumerT.start();
        
    }



    /* (non-Javadoc)
     * @see com.admiral.rnd.claims.orchestrator.IOrchestrator#stop()
     */
    @Override
    public void stop() {
        interactionConsumer.shutdown();
        selfServiceConsumer.shutdown();
    }

}
