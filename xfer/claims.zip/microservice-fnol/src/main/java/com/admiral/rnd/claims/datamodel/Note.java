package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Note extends Entity {

    @JsonProperty
    @BsonProperty
    private String text;


    @JsonProperty
    @BsonProperty
    private NoteTypeEnum type;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param text
     * @param type
     */
    @JsonCreator
    public Note(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("text") @BsonProperty("text") String text,
            @JsonProperty("type") @BsonProperty("type") NoteTypeEnum type) {
        super(id, createdAt, updatedAt);
        this.text = text;
        this.type = type;
    }

    @BsonCreator
    public Note() {
    }

    
    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    
    /**
     * @param text the text to set
     */
    public void setText(String text) {
        this.text = text;
    }

    
    /**
     * @return the type
     */
    public NoteTypeEnum getType() {
        return type;
    }

    
    /**
     * @param type the type to set
     */
    public void setType(NoteTypeEnum type) {
        this.type = type;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Note [text=" + text + ", type=" + type + "]";
    }

}
