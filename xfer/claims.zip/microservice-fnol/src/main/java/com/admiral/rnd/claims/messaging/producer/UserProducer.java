package com.admiral.rnd.claims.messaging.producer;

import javax.inject.Singleton;

import com.admiral.rnd.claims.messaging.producer.api.IUserProducer;

import io.micronaut.context.annotation.Property;

@Singleton
public class UserProducer extends ClaimsProducer implements IUserProducer {

    public UserProducer(@Property(name = "kafka.bootstrap.servers") String servers,
                        @Property(name = "kafka.users.topicname") String topic) {
        super(servers, topic);
    }

}
