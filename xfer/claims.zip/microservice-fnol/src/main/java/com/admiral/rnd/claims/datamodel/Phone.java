package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Phone extends Entity {

    @JsonProperty
    @BsonProperty
    private String number;

    @JsonProperty
    @BsonProperty
    private List<PhoneTypeEnum> types;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param number
     * @param types
     */
    @JsonCreator
    public Phone(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("number") @BsonProperty("number") String number,
            @JsonProperty("types") @BsonProperty("types") List<PhoneTypeEnum> types) {
        super(id, createdAt, updatedAt);
        this.number = number;
        this.types = types;
    }
    
    @BsonCreator
    public Phone() {
    }

    
    /**
     * @return the number
     */
    public String getNumber() {
        return number;
    }

    
    /**
     * @param number the number to set
     */
    public void setNumber(String number) {
        this.number = number;
    }

    
    /**
     * @return the types
     */
    public List<PhoneTypeEnum> getTypes() {
        return types;
    }

    
    /**
     * @param types the types to set
     */
    public void setTypes(List<PhoneTypeEnum> types) {
        this.types = types;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Phone [number=" + number + ", types=" + types + "]";
    }


    

}
