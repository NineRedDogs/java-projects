package com.admiral.rnd.claims.datamodel;

public enum InteractionVerificationEnum {
    DATA_PROTECTION_CHECK, PHONE_MATCH, UNCHECKED
}
