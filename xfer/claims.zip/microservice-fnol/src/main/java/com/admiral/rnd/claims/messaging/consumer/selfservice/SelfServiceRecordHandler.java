package com.admiral.rnd.claims.messaging.consumer.selfservice;

import java.io.IOException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.events.Event;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.RecordHandler;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SelfServiceRecordHandler extends RecordHandler {

    private static final Logger LOG = LoggerFactory.getLogger(SelfServiceRecordHandler.class);


    public SelfServiceRecordHandler(ConsumerRecord<String, TopicRecord> consumerRecord) {
        super(consumerRecord);
        LOG.debug("SelfServiceRecordHandler: ctor");

    }

    public void run() {
        try {
            Event event  = getEventObject(getEvent());
            
            // now we have a java object we can process the incoming event....
            processEvent(getId(), getRecordId(), event);

        } catch (JsonParseException | JsonMappingException e) {
            // unexpected event type, not for us, so leave for another handler 
        } catch (IOException e) {
            // unexpected event type, not for us, so leave for another handler 
        }
    }

    /**
     * Convert event json into Event object.
     * 
     * @param eventJson raw json data
     * @return Event object
     * @throws JsonParseException if problem parsing json
     * @throws JsonMappingException if problem parsing json
     * @throws IOException if problem parsing json
     */
    public Event getEventObject(String eventJson) throws JsonParseException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(eventJson, Event.class);
    }

    private void processEvent(String eventId, String interactionId, Event ci) {
        
        // 1. just received a case interaction event
        // 2. need to extract id
        // 3. check if expected phase, e.g. ss1, ss2, etc
        // 4. extract data from topic record
        // 5. upsert case-ss-record into db
        // 6. if end-phase, then add a new self service event to self service topic
        // 


        // (3) Publish response event, so all interested parties can react
        //ObjectMapper mapper = new ObjectMapper();
        //String respJson="{}";
        //try {
        //    respJson = mapper.writeValueAsString(resp);
        //    CaseProducer.INSTANCE.postEvent(caseId, new TopicRecord(ciId, respJson));
        //} catch (JsonProcessingException e) {
        //    LOG.info("Caught JsonProcessingException when generating WS Response JSON, e:" + e.getMessage());
        //}
    }

}
