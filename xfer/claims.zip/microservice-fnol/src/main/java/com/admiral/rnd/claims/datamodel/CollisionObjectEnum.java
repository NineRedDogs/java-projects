package com.admiral.rnd.claims.datamodel;

public enum CollisionObjectEnum {
    LAMPOST, WALL, TREE, ANIMAL, OTHER
}
