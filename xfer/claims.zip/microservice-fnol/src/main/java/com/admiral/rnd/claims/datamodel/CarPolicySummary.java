package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CarPolicySummary extends PolicySummary {
    
    public static final String TYPE_NAME = "CarPolicySummary";


    @JsonProperty
    @BsonProperty
    private List<Vehicle> vehicles;


    @JsonProperty
    @BsonProperty
    private CarCoverEnum cover;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param policyNumber
     * @param startsOn
     * @param endsOn
     * @param noClaimsBonus
     * @param policyHolders
     * @param caseIds
     * @param vehicles
     * @param cover
     */
    @JsonCreator
    public CarPolicySummary(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("policyNumber") @BsonProperty("policyNumber") String policyNumber,
            @JsonProperty("startsOn") @BsonProperty("startsOn") String startsOn, 
            @JsonProperty("endsOn") @BsonProperty("endsOn") String endsOn,
            @JsonProperty("noClaimsBonus") @BsonProperty("noClaimsBonus") int noClaimsBonus,
            @JsonProperty("policyHolders") @BsonProperty("policyHolders") List<Contact> policyHolders,
            @JsonProperty("caseIds") @BsonProperty("caseIds") List<String> caseIds,
            @JsonProperty("vehicles") @BsonProperty("vehicles") List<Vehicle> vehicles, 
            @JsonProperty("cover") @BsonProperty("cover") CarCoverEnum cover) {
        super(id, createdAt, updatedAt, TYPE_NAME, policyNumber, startsOn, endsOn, noClaimsBonus, policyHolders, caseIds);
        this.vehicles = vehicles;
        this.cover = cover;
    }

    @BsonCreator
    public CarPolicySummary() {
    }

    
    /**
     * @return the vehicles
     */
    public List<Vehicle> getVehicles() {
        return vehicles;
    }

    
    /**
     * @param vehicles the vehicles to set
     */
    public void setVehicles(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }

    
    /**
     * @return the cover
     */
    public CarCoverEnum getCover() {
        return cover;
    }

    
    /**
     * @param cover the cover to set
     */
    public void setCover(CarCoverEnum cover) {
        this.cover = cover;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " CarPolicySummary [vehicles=" + vehicles + ", cover=" + cover + "]";
    }

}
