package com.admiral.rnd.claims.messaging.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import com.admiral.rnd.claims.messaging.TopicRecord;

public abstract class RecordHandler implements Runnable {

    /** The record to handle. */
    private final ConsumerRecord<String, TopicRecord> consumerRecord;

    /**
     * Constructor.
     * 
     * @param consumerRecord
     */
    public RecordHandler(ConsumerRecord<String, TopicRecord> consumerRecord) {
        this.consumerRecord = consumerRecord;
    }

    /**
     * @return the consumerRecord
     */
    public ConsumerRecord<String, TopicRecord> getRecord() {
        return consumerRecord;
    }
    
    /**
     * @return case id
     */
    protected String getId() {
        return (String) getRecord().key();
    }

    /**
     * @return event
     */
    protected String getEvent() {
        return getRecord().value().getRecordData();
    }
    
    /**
     * @return ws session id
     */
    protected String getRecordId() {
        return getRecord().value().getRecordId();
    }
    
}
