package com.admiral.rnd.claims.datamodel.events;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.AtFaultEnum;
import com.admiral.rnd.claims.datamodel.CarIncidentCase;
import com.admiral.rnd.claims.datamodel.CarIncidentCategoryEnum;
import com.admiral.rnd.claims.datamodel.CollisionCauseEnum;
import com.admiral.rnd.claims.datamodel.CollisionObjectEnum;
import com.admiral.rnd.claims.datamodel.CollisionTypeEnum;
import com.admiral.rnd.claims.datamodel.JourneyReasonEnum;
import com.admiral.rnd.claims.datamodel.Location;
import com.admiral.rnd.claims.db.DbHelperCarCase;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SelfServiceCircumstancesEvent extends Event {

    private static final Logger LOG = LoggerFactory.getLogger(SelfServiceCircumstancesEvent.class);

    // ss2
    protected static final String EVENT_NAME = "SelfServiceCircumstancesEvent";
    
    private static final List<Class<?>> validTransitions = Collections.unmodifiableList(Arrays.asList(
            SelfServiceVehicleEvent.class));

    @JsonProperty
    @BsonProperty
    private CarIncidentCategoryEnum category;

    @JsonProperty
    @BsonProperty
    private CollisionCauseEnum collisionCause;

    @JsonProperty
    @BsonProperty
    private CollisionTypeEnum collisionType;

    @JsonProperty
    @BsonProperty
    private CollisionObjectEnum collisionObject;

    @JsonProperty
    @BsonProperty
    private JourneyReasonEnum journeyReason;

    @JsonProperty    @BsonProperty
    private AtFaultEnum policyHolderAtFault;

    @JsonProperty
    @BsonProperty
    private Location incidentLocation;

    /**
     * @param id
     * @param interactionId
     * @param name
     * @param category
     * @param collisionCause
     * @param collisionType
     * @param collisionObject
     * @param journeyReason
     * @param policyHolderAtFault
     * @param incidentLocation
     */
    @JsonCreator
    public SelfServiceCircumstancesEvent(
                      @JsonProperty("id") @BsonProperty("id") String id, 
                      @JsonProperty("interactionId") @BsonProperty("interactionId") String interactionId, 
                      @JsonProperty("category") @BsonProperty("category") CarIncidentCategoryEnum category,
                      @JsonProperty("collisionCause") @BsonProperty("collisionCause") CollisionCauseEnum collisionCause, 
                      @JsonProperty("collisionType") @BsonProperty("collisionType") CollisionTypeEnum collisionType, 
                      @JsonProperty("collisionObject") @BsonProperty("collisionObject") CollisionObjectEnum collisionObject,
                      @JsonProperty("journeyReason") @BsonProperty("journeyReason") JourneyReasonEnum journeyReason, 
                      @JsonProperty("policyHolderAtFault") @BsonProperty("policyHolderAtFault") AtFaultEnum policyHolderAtFault, 
                      @JsonProperty("incidentLocation") @BsonProperty("incidentLocation") Location incidentLocation) {
        super(id, interactionId, EVENT_NAME);
        this.category = category;
        this.collisionCause = collisionCause;
        this.collisionType = collisionType;
        this.collisionObject = collisionObject;
        this.journeyReason = journeyReason;
        this.policyHolderAtFault = policyHolderAtFault;
        this.incidentLocation = incidentLocation;
    }

    @BsonCreator
    public SelfServiceCircumstancesEvent() {}

    /**
     * @return the category
     */
    public CarIncidentCategoryEnum getCategory() {
        return category;
    }


    /**
     * @param category the category to set
     */
    public void setCategory(CarIncidentCategoryEnum category) {
        this.category = category;
    }


    /**
     * @return the collisionCause
     */
    public CollisionCauseEnum getCollisionCause() {
        return collisionCause;
    }


    /**
     * @param collisionCause the collisionCause to set
     */
    public void setCollisionCause(CollisionCauseEnum collisionCause) {
        this.collisionCause = collisionCause;
    }


    /**
     * @return the collisionType
     */
    public CollisionTypeEnum getCollisionType() {
        return collisionType;
    }


    /**
     * @param collisionType the collisionType to set
     */
    public void setCollisionType(CollisionTypeEnum collisionType) {
        this.collisionType = collisionType;
    }


    /**
     * @return the collisionObject
     */
    public CollisionObjectEnum getCollisionObject() {
        return collisionObject;
    }


    /**
     * @param collisionObject the collisionObject to set
     */
    public void setCollisionObject(CollisionObjectEnum collisionObject) {
        this.collisionObject = collisionObject;
    }


    /**
     * @return the journeyReason
     */
    public JourneyReasonEnum getJourneyReason() {
        return journeyReason;
    }


    /**
     * @param journeyReason the journeyReason to set
     */
    public void setJourneyReason(JourneyReasonEnum journeyReason) {
        this.journeyReason = journeyReason;
    }


    /**
     * @return the policyHolderAtFault
     */
    public AtFaultEnum getPolicyHolderAtFault() {
        return policyHolderAtFault;
    }


    /**
     * @param policyHolderAtFault the policyHolderAtFault to set
     */
    public void setPolicyHolderAtFault(AtFaultEnum policyHolderAtFault) {
        this.policyHolderAtFault = policyHolderAtFault;
    }


    /**
     * @return the incidentLocation
     */
    public Location getIncidentLocation() {
        return incidentLocation;
    }


    /**
     * @param incidentLocation the incidentLocation to set
     */
    public void setIncidentLocation(Location incidentLocation) {
        this.incidentLocation = incidentLocation;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " SelfServiceCircumstancesEvent [category=" + category + ", collisionCause="
                + collisionCause + ", collisionType=" + collisionType + ", collisionObject=" + collisionObject
                + ", journeyReason=" + journeyReason + ", policyHolderAtFault=" + policyHolderAtFault
                + ", incidentLocation=" + incidentLocation + "]";
    }

    @Override
    protected List<Class<?>> getValidTransitions() {
        return validTransitions;
    }

    protected void addSelfServiceEventData(final CarIncidentCase ciCase, DbHelperCarCase dbAccessor) {
        super.addSelfServiceEventData(ciCase, dbAccessor);
        // add properties from this Circumstances SS event
        // now set the new CarIncidentCase instance properties with those of this SelfServiceEvent
        ciCase.setCategory(getCategory());
        ciCase.setCollisionCause(getCollisionCause());
        ciCase.setCollisionType(getCollisionType());
        ciCase.setCollisionObjectType(getCollisionObject());
        ciCase.setJourneyReason(getJourneyReason());
        ciCase.setPolicyHolderAtFault(getPolicyHolderAtFault());
        ciCase.setLocation(getIncidentLocation());
    }
    
    @Override
    public void postUpdatedCase(CarIncidentCase ciCase, ICaseProducer caseProducer) {
        // nothing to post - mid-way through a set of interactions ....
        LOG.info("NOT posting case to TOPIC : SelfService phase 2...");
    }

    


}
