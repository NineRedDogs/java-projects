package com.admiral.rnd.claims.datamodel;

public enum CollisionCauseEnum {
    POLICY_HOLDER_HIT_VEHICLE, POLICY_HOLDER_HIT_OBJECT, THIRD_PARTY_HIT_VEHICLE, OTHER
}
