package com.admiral.rnd.claims.messaging;

import java.io.Serializable;

public class TopicRecord implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private final String recordId;
    private final String recordData;
    
    public TopicRecord(String recordId, String recordData) {
        super();
        this.recordId = recordId;
        this.recordData = recordData;
    }
    
    /**
     * @return the recordId
     */
    public String getRecordId() {
        return recordId;
    }
    
    /**
     * @return the recordData
     */
    public String getRecordData() {
        return recordData;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "TopicRecord [recordId=" + recordId + ", recordData=" + recordData + "]";
    }

}
