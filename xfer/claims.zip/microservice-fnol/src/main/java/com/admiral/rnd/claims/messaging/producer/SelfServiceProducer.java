package com.admiral.rnd.claims.messaging.producer;

import javax.inject.Singleton;

import com.admiral.rnd.claims.messaging.producer.api.ISelfServiceProducer;

import io.micronaut.context.annotation.Property;

@Singleton
public class SelfServiceProducer extends ClaimsProducer implements ISelfServiceProducer {

    public SelfServiceProducer(@Property(name = "kafka.bootstrap.servers") String servers,
                               @Property(name = "kafka.selfservice.topicname") String topic) {
        super(servers, topic);
    }

}
