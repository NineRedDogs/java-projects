package com.admiral.rnd.claims.messaging.consumer.carcase;

import java.io.IOException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.WsCallback;
import com.admiral.rnd.claims.datamodel.Case;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.consumer.RecordHandler;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CaseRecordHandler extends RecordHandler {
    
    private static final Logger LOG = LoggerFactory.getLogger(CaseRecordHandler.class);

    private WsCallback cb;

    public CaseRecordHandler(ConsumerRecord<String, TopicRecord> consumerRecord, WsCallback cb) {
        super(consumerRecord);
        this.cb = cb;
    }

    public void run() {
        try {
            LOG.info("AJG: Case Response Record Handler ");
            Case ciCase = getCaseObject(getEvent());

            // now we have a java object we can process the incoming event....
            processCaseEvent(getId(), getRecordId(), ciCase);
            
        } catch (JsonParseException | JsonMappingException e) {
            // unexpected event type, not for us, so leave for another handler 
        } catch (IOException e) {
            // unexpected event type, not for us, so leave for another handler 
        }
    }

    /**
     * Convert event json into Response object.
     * 
     * @param eventJson raw json data
     * @return Kase object
     * @throws JsonParseException if problem parsing json
     * @throws JsonMappingException if problem parsing json
     * @throws IOException if problem parsing json
     */
    public Case getCaseObject(String eventJson) throws JsonParseException, JsonMappingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(eventJson, Case.class);
    }

    private void processCaseEvent(String caseId, String wsSessionId, Case ciCase) {
        
        //
        // TODO (1) write data to mongoDb
        // 
        
        
        // TODO (2) do some business flow look-up to see what we need to send back to WS client        
        
        
        // (3) Send response over WS connection ....
        cb.caseToReturn(ciCase, caseId, wsSessionId);
        
    }
}
