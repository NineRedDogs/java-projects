package com.admiral.rnd.claims;

import com.admiral.rnd.claims.datamodel.Case;

public interface WsCallback {
    
    public void caseToReturn(Case response, String caseId, String wsSessionId);

}
