package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonDiscriminator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@BsonDiscriminator
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")  
@JsonSubTypes({ @Type(value = Case.class, name = Case.TYPE_NAME), 
                @Type(value = IncidentCase.class, name = IncidentCase.TYPE_NAME), 
                @Type(value = CarIncidentCase.class, name = CarIncidentCase.TYPE_NAME), 
                @Type(value = HouseIncidentCase.class, name = HouseIncidentCase.TYPE_NAME),
                @Type(value = ClaimCase.class, name = ClaimCase.TYPE_NAME),
                @Type(value = CarClaimCase.class, name = CarClaimCase.TYPE_NAME), 
                @Type(value = HouseClaimCase.class, name = HouseClaimCase.TYPE_NAME) }) 
public class Case extends Entity {
    
    protected static final String TYPE_NAME = "Case";
    
    @JsonProperty
    @BsonProperty(useDiscriminator = true)
    private String type;

    @JsonProperty
    @BsonProperty
    private List<CaseAssociation> associations;

    @JsonProperty
    @BsonProperty
    private String module;

    @JsonProperty
    @BsonProperty
    private List<Note> notes;

    @JsonProperty
    @BsonProperty
    private List<String> interactions;

    /**
     * @param type
     * @param cases
     */
    @JsonCreator
    public Case(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations,
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions) {
        super(id, createdAt, updatedAt);
        this.type = type;
        this.associations = associations;
        this.module = module;
        this.notes = notes;
        this.interactions = interactions;
    }
    
    @BsonCreator
    public Case() {}

    
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    
    /**
     * @return the associations
     */
    public List<CaseAssociation> getAssociations() {
        return associations;
    }

    
    /**
     * @param associations the associations to set
     */
    public void setAssociations(List<CaseAssociation> associations) {
        this.associations = associations;
    }

    
    /**
     * @return the module
     */
    public String getModule() {
        return module;
    }

    
    /**
     * @param module the module to set
     */
    public void setModule(String module) {
        this.module = module;
    }

    
    /**
     * @return the notes
     */
    public List<Note> getNotes() {
        return notes;
    }

    
    /**
     * @param notes the notes to set
     */
    public void setNotes(List<Note> notes) {
        this.notes = notes;
    }

    /**
     * @return the interactions
     */
    public List<String> getInteractions() {
        return interactions;
    }

    
    /**
     * @param notes the notes to set
     */
    public void setInteractions(List<String> interactions) {
        this.interactions = interactions;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Case [type=" + type + ", associations=" + associations + ", module=" + module + ", notes=" + notes
                + ", interactions=" + interactions + "]";
    }

    

}
