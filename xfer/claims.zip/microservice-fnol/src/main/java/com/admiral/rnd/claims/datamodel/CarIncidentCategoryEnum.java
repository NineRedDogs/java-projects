package com.admiral.rnd.claims.datamodel;

public enum CarIncidentCategoryEnum {
    WINDSCREEN, COLLISION, MALICIOUS_DAMAGE, FIRE, THEFT, FLOOD, OTHER
}
