package com.admiral.rnd.claims.messaging;

import java.util.Map;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.common.serialization.Serializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;


public class TopicRecordSerializer implements Serializer<TopicRecord> {
    private static final Logger LOG = LoggerFactory.getLogger(TopicRecordSerializer.class);

    ObjectMapper om = new ObjectMapper();
    
    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        LOG.debug("TopicRecordSerializer: configure");
    }

    @Override
    public byte[] serialize(String topic, TopicRecord wsCaseReq) {
        byte[] byteData = SerializationUtils.serialize(wsCaseReq);
        return byteData;
    }

    @Override
    public void close() {
    }

}
