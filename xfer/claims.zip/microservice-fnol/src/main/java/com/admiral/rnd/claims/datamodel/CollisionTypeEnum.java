package com.admiral.rnd.claims.datamodel;

public enum CollisionTypeEnum {
    REAR, PARKED_AND_UNATTENDED, SIDE_ROAD, REVERSING, CHANGING_LANES, ROUNDABOUT, OTHER
}
