package com.admiral.rnd.claims.datamodel;

import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Contact extends Entity {

    @JsonProperty
    @BsonProperty
    private List<ContactTypeEnum> types;

    @JsonProperty
    @BsonProperty
    private String firstName;

    @JsonProperty
    @BsonProperty
    private String lastName;

    @JsonProperty
    @BsonProperty
    private String email;

    @JsonProperty
    @BsonProperty
    private List<Phone> phones;

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param types
     * @param firstName
     * @param lastName
     * @param email
     * @param phones
     */
    @JsonCreator
    public Contact(@JsonProperty("id") @BsonProperty("id") String id, 
                   @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
                   @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
                   @JsonProperty("types") @BsonProperty("types") List<ContactTypeEnum> types,
                   @JsonProperty("firstName") @BsonProperty("firstName") String firstName, 
                   @JsonProperty("lastName") @BsonProperty("lastName") String lastName,
                   @JsonProperty("email") @BsonProperty("email") String email, 
                   @JsonProperty("phones") @BsonProperty("phones") List<Phone> phones) {
        super(id, createdAt, updatedAt);
        this.types = types;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phones = phones;
    }

    @BsonCreator
    public Contact() {
    }

    
    /**
     * @return the type
     */
    public List<ContactTypeEnum> getType() {
        return types;
    }

    
    /**
     * @param type the type to set
     */
    public void setType(List<ContactTypeEnum> type) {
        this.types = type;
    }

    
    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    
    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    
    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    
    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    
    /**
     * @return the phones
     */
    public List<Phone> getPhones() {
        return phones;
    }

    
    /**
     * @param phones the phones to set
     */
    public void setPhones(List<Phone> phones) {
        this.phones = phones;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " Contact [types=" + types + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
                + ", phones=" + phones + "]";
    }

    
}
