package com.admiral.rnd.claims.messaging.consumer;

import java.time.Duration;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.WsCallback;
import com.admiral.rnd.claims.messaging.TopicRecord;

public abstract class TopicConsumer implements Runnable {
    private static final Logger LOG = LoggerFactory.getLogger(TopicConsumer.class);
    
    public final Duration pollPeriod;
    
    private final KafkaConsumer<String, TopicRecord> consumer;
    
    private enum ConsumerStateEnum { Init, Running, Stopped };
    private ConsumerStateEnum consumerState;
    
    private WsCallback cb;

    private Object LOCK = new Object();
    
    // consumer threadpool
    private ExecutorService executor;
    private int numThreads;
    private final String id;
    
    private final String desc;
    
    public TopicConsumer(long pollPeriodMs, 
            List<String> subscribeInfo, 
            String brokers, 
            String groupId, 
            int numThreads, 
            String desc) {
        this.id = Integer.toHexString(System.identityHashCode(this));
        Properties prop = createConsumerConfig(brokers, groupId+"__"+this.id);
        pollPeriod = Duration.ofMillis(pollPeriodMs);
        StringBuilder sb = new StringBuilder("subscribe to : ");
        for (String subs : subscribeInfo) {
            sb.append(subs);
        }
        this.consumer = new KafkaConsumer<>(prop);
        this.numThreads = numThreads;
        this.consumerState = ConsumerStateEnum.Init;
        this.desc = desc;

        // TODO regexp/smarter subscribe for specific case id ???
        this.consumer.subscribe(subscribeInfo);
    }

    private static Properties createConsumerConfig(String brokers, String groupId) {
        Properties props = new Properties();
        props.put("bootstrap.servers", brokers);
        props.put("group.id", groupId);
        props.put("enable.auto.commit", "true");
        props.put("auto.commit.interval.ms", "1000");
        props.put("session.timeout.ms", "30000");
        props.put("auto.offset.reset", "latest"); // i.e. automatically reset the offset to the latest offset
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "com.admiral.rnd.claims.messaging.TopicRecordDeserializer");
        return props;
    }

    public void startConsumer() {
        synchronized (LOCK) {
            consumerState = ConsumerStateEnum.Running;
        }
    }

    public boolean consumerRunning() {
        synchronized (LOCK) {
            return consumerState == ConsumerStateEnum.Running;
        }
    }

    public void stopConsumer() {
        synchronized (LOCK) {
            consumerState = ConsumerStateEnum.Stopped;
        }
    }

    public boolean consumerStopped() {
        synchronized (LOCK) {
            return consumerState == ConsumerStateEnum.Stopped;
        }
    }

    public void shutdown() {
        synchronized (LOCK) {
            if (consumer != null) {
                consumer.close();
            }
            if (executor != null) {
                executor.shutdown();
            }
            try {
                if (!executor.awaitTermination(5000, TimeUnit.MILLISECONDS)) {
                    out("Timed out waiting for consumer threads to shut down, exiting uncleanly");
                }
            } catch (InterruptedException e) {
                out("Interrupted during shutdown, exiting uncleanly");
            }
        }
    }
    
    @Override
    public void run() {
        // Create ThreadPool and use the BlockingQueue with size =1000 to
        // hold submitted tasks.
        executor = new ThreadPoolExecutor(numThreads, numThreads, 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<Runnable>(1000), new ThreadPoolExecutor.CallerRunsPolicy());

        while (!consumerStopped()) {
            ConsumerRecords<String, TopicRecord> records = consumer.poll(pollPeriod);
            for (final ConsumerRecord<String, TopicRecord> record : records) {
                executor.submit(newHandler(record));
            }
        }
    }
    
    

    
    /**
     * @return the cb
     */
    public WsCallback getCallback() {
        return cb;
    }

    
    /**
     * @param cb the cb to set
     */
    public void setCallback(WsCallback cb) {
        this.cb = cb;
    }

    protected abstract Runnable newHandler(final ConsumerRecord<String, TopicRecord> record);
    
    private void out(final String message) {
        LOG.info("[" + id + "] " + desc + ":" + message);
    }
}
