package com.admiral.rnd.claims.datamodel;

import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CarClaimCase extends ClaimCase {
    
    protected static final String TYPE_NAME = "CarClaimCase";

    @JsonProperty
    @BsonProperty
    private List<CarLossEnum> losses;


    @JsonProperty
    @BsonProperty
    private Vehicle vehicle; // optional


    @JsonProperty
    @BsonProperty
    private boolean drivable; // optional


    @JsonProperty
    @BsonProperty
    private int passengerCount; // optional


    @JsonProperty
    @BsonProperty
    private SpeedRangeEnum speedRange; // optional


    @JsonProperty
    @BsonProperty
    private List<VehicleDamage> damages; // optional

    /**
     * @param id
     * @param createdAt
     * @param updatedAt
     * @param associations
     * @param module
     * @param notes
     * @param contacts
     * @param thirdParty
     * @param assessment
     * @param losses
     * @param vehicle
     * @param drivable
     * @param passengerCount
     * @param speedRange
     * @param damages
     */
    @JsonCreator
    public CarClaimCase(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            //@JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations, 
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions,
            @JsonProperty("contacts") @BsonProperty("contacts") List<Contact> contacts,
            @JsonProperty("thirdParty") @BsonProperty("thirdParty") boolean thirdParty,
            @JsonProperty("assessment") @BsonProperty("assessment") LossAssessmentEnum assessment, 
            @JsonProperty("losses") @BsonProperty("losses") List<CarLossEnum> losses,
            @JsonProperty("vehicle") @BsonProperty("vehicle") Vehicle vehicle, 
            @JsonProperty("drivable") @BsonProperty("drivable") boolean drivable,
            @JsonProperty("passengerCount") @BsonProperty("passengerCount") int passengerCount, 
            @JsonProperty("speedRange") @BsonProperty("speedRange") SpeedRangeEnum speedRange,
            @JsonProperty("damages") @BsonProperty("damages") List<VehicleDamage> damages) {
        super(id, createdAt, updatedAt, TYPE_NAME, associations, module, notes, interactions, contacts, thirdParty, assessment);
        this.losses = losses;
        this.vehicle = vehicle;
        this.drivable = drivable;
        this.passengerCount = passengerCount;
        this.speedRange = speedRange;
        this.damages = damages;
    }

    @BsonCreator
    public CarClaimCase() {
    }

    
    /**
     * @return the losses
     */
    public List<CarLossEnum> getLosses() {
        return losses;
    }

    
    /**
     * @param losses the losses to set
     */
    public void setLosses(List<CarLossEnum> losses) {
        this.losses = losses;
    }

    
    /**
     * @return the vehicle
     */
    public Vehicle getVehicle() {
        return vehicle;
    }

    
    /**
     * @param vehicle the vehicle to set
     */
    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    
    /**
     * @return the drivable
     */
    public boolean isDrivable() {
        return drivable;
    }

    
    /**
     * @param drivable the drivable to set
     */
    public void setDrivable(boolean drivable) {
        this.drivable = drivable;
    }

    
    /**
     * @return the passengerCount
     */
    public int getPassengerCount() {
        return passengerCount;
    }

    
    /**
     * @param passengerCount the passengerCount to set
     */
    public void setPassengerCount(int passengerCount) {
        this.passengerCount = passengerCount;
    }

    
    /**
     * @return the speedRange
     */
    public SpeedRangeEnum getSpeedRange() {
        return speedRange;
    }

    
    /**
     * @param speedRange the speedRange to set
     */
    public void setSpeedRange(SpeedRangeEnum speedRange) {
        this.speedRange = speedRange;
    }

    
    /**
     * @return the damages
     */
    public List<VehicleDamage> getDamages() {
        return damages;
    }

    
    /**
     * @param damages the damages to set
     */
    public void setDamages(List<VehicleDamage> damages) {
        this.damages = damages;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " CarClaimCase [losses=" + losses + ", vehicle=" + vehicle + ", drivable=" + drivable
                + ", passengerCount=" + passengerCount + ", speedRange=" + speedRange + ", damages=" + damages + "]";
    }


}
