package com.admiral.rnd.claims.datamodel;

public enum EmergencyServiceEnum {
    POLICE, AMBULANCE, FIRE
}
