package com.admiral.rnd.claims.rest.selfservice;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.inject.Singleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.events.Event;
import com.admiral.rnd.claims.orchestrator.exceptions.IllegalTransitionException;

@Singleton
public class Interactions implements IInteractions {
    private static final Logger LOG = LoggerFactory.getLogger(Interactions.class);

    private Map<String, Event> interactions;
    
    private Object LOCK = new Object();
    
    public Interactions() {
        interactions = new ConcurrentHashMap<String, Event>();
    }
    
    /* (non-Javadoc)
     * @see com.admiral.rnd.claims.rest.selfservice.IInteractions#transitionInteraction(com.admiral.rnd.claims.datamodel.events.Event)
     */
    @Override
    public void transitionInteraction(final Event event) throws IllegalTransitionException {
        
        final String interactionId = event.getInteractionId();
        
        // is there an entry for this interaction
        Event ie = getInteraction(interactionId);
        
        // see if interaction is known to us
        if (ie == null) {
            LOG.info("Could not find interaction [" + interactionId + "]");
            
            // new interaction, just check that the first interaction is the expected event
            if (event.canBeAnInitialEvent()) {
                addInteraction(interactionId, event);
            } else {
                throw new IllegalTransitionException("Illegal initial event : " + event.getClass().getName());
            }
        } else {
            LOG.info("Successfully found interaction [" + interactionId + "]");
            // can we move from previous event to new event
            if (ie.validTransition(event.getClass())) {
                addInteraction(interactionId, event);
            } else {
                throw new IllegalTransitionException("Illegal transition (" + ie.getClass().getName() + ">" 
                                                     + event.getClass().getName() + " for interaction : " + interactionId);
            }
        }
    }

    private Event addInteraction(String interactionId, Event event) {
        synchronized (LOCK) {
            LOG.info("Updating interaction (" + interactionId + ") state > " + event.getClass().getName());
            return interactions.put(interactionId, event);
        }
    }

    private Event getInteraction(String interactionId) {
        synchronized (LOCK) {
            return interactions.get(interactionId);
        }
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        synchronized (LOCK) {
            return "Interactions [interactions=" + Arrays.toString(interactions.entrySet().toArray()) + "]";
        }
    }
    
    

}
