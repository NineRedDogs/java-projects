package com.admiral.rnd.claims.datamodel;

public enum JourneyReasonEnum {
    COMMUTING, VISITING_FRIENDS_RELATIVES, SHOPPING, SOCIAL, SCHOOL_RUN, BUSINESS, OTHER
}
