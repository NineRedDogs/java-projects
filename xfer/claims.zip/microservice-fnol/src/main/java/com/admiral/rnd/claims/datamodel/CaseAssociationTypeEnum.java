package com.admiral.rnd.claims.datamodel;

public enum CaseAssociationTypeEnum {
    PARENT, CHILD, RELATED, DUPLICATE, SIBLING
}
