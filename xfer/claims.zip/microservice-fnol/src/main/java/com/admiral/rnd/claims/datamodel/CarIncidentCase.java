package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CarIncidentCase extends IncidentCase {
    
    protected static final String TYPE_NAME = "CarIncidentCase";

    @JsonProperty
    @BsonProperty
    private CarPolicySummary policy;

    @JsonProperty
    @BsonProperty
    private CarIncidentCategoryEnum category;

    @JsonProperty
    @BsonProperty
    private boolean recoveryRequired;

    @JsonProperty
    @BsonProperty
    private Location recoveryLocation;

    @JsonProperty
    @BsonProperty
    private CollisionCauseEnum collisionCause;

    @JsonProperty
    @BsonProperty
    private CollisionTypeEnum collisionType;

    @JsonProperty
    @BsonProperty
    private CollisionObjectEnum collisionObjectType; // optional

    @JsonProperty
    @BsonProperty
    private JourneyReasonEnum journeyReason;
    
    @JsonCreator
    public CarIncidentCase(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            //@JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations, 
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions,
            @JsonProperty("occurredAt") @BsonProperty("occurredAt") String occurredAt,
            @JsonProperty("location") @BsonProperty("location") Location location,
            @JsonProperty("seriousInjury") @BsonProperty("seriousInjury") boolean seriousInjury, 
            @JsonProperty("crimeReference") @BsonProperty("crimeReference") String crimeReference,
            @JsonProperty("emergencyServices") @BsonProperty("emergencyServices") List<EmergencyServiceEnum> emergencyServices,
            @JsonProperty("policyHolderAtFault") @BsonProperty("policyHolderAtFault") AtFaultEnum policyHolderAtFault,
            @JsonProperty("contacts") @BsonProperty("contacts") List<Contact> contacts, 
            @JsonProperty("policy") @BsonProperty("policy") CarPolicySummary policy, 
            @JsonProperty("category") @BsonProperty("category") CarIncidentCategoryEnum category,
            @JsonProperty("recoveryRequired") @BsonProperty("recoveryRequired") boolean recoveryRequired,
            @JsonProperty("recoveryLocation") @BsonProperty("recoveryLocation") Location recoveryLocation,
            @JsonProperty("collisionCause") @BsonProperty("collisionCause") CollisionCauseEnum collisionCause,
            @JsonProperty("collisionType") @BsonProperty("collisionType") CollisionTypeEnum collisionType,
            @JsonProperty("collisionObjectType") @BsonProperty("collisionObjectType") CollisionObjectEnum collisionObjectType,
            @JsonProperty("journeyReason") @BsonProperty("journeyReason") JourneyReasonEnum journeyReason) {
        super(id, createdAt, updatedAt, TYPE_NAME, associations, module, notes, interactions, occurredAt, location, 
                  seriousInjury, crimeReference, emergencyServices, policyHolderAtFault, contacts);
        this.policy = policy;
        this.category = category;
        this.recoveryRequired = recoveryRequired;
        this.recoveryLocation = recoveryLocation;
        this.collisionCause = collisionCause;
        this.collisionType = collisionType;
        this.collisionObjectType = collisionObjectType;
        this.journeyReason = journeyReason;
    }

    @BsonCreator
    public CarIncidentCase() {
    }

    
    /**
     * @return the policy
     */
    public CarPolicySummary getPolicy() {
        return policy;
    }

    
    /**
     * @param policy the policy to set
     */
    public void setPolicy(CarPolicySummary policy) {
        this.policy = policy;
    }

    
    /**
     * @return the category
     */
    public CarIncidentCategoryEnum getCategory() {
        return category;
    }

    
    /**
     * @param category the category to set
     */
    public void setCategory(CarIncidentCategoryEnum category) {
        this.category = category;
    }

    
    /**
     * @return the recoveryRequired
     */
    public boolean isRecoveryRequired() {
        return recoveryRequired;
    }

    
    /**
     * @param recoveryRequired the recoveryRequired to set
     */
    public void setRecoveryRequired(boolean recoveryRequired) {
        this.recoveryRequired = recoveryRequired;
    }

    
    /**
     * @return the recoveryLocation
     */
    public Location getRecoveryLocation() {
        return recoveryLocation;
    }

    
    /**
     * @param recoveryLocation the recoveryLocation to set
     */
    public void setRecoveryLocation(Location recoveryLocation) {
        this.recoveryLocation = recoveryLocation;
    }

    
    /**
     * @return the collisionCause
     */
    public CollisionCauseEnum getCollisionCause() {
        return collisionCause;
    }

    
    /**
     * @param collisionCause the collisionCause to set
     */
    public void setCollisionCause(CollisionCauseEnum collisionCause) {
        this.collisionCause = collisionCause;
    }

    
    /**
     * @return the collisionType
     */
    public CollisionTypeEnum getCollisionType() {
        return collisionType;
    }

    
    /**
     * @param collisionType the collisionType to set
     */
    public void setCollisionType(CollisionTypeEnum collisionType) {
        this.collisionType = collisionType;
    }

    
    /**
     * @return the collisionObjectType
     */
    public CollisionObjectEnum getCollisionObjectType() {
        return collisionObjectType;
    }

    
    /**
     * @param collisionObjectType the collisionObjectType to set
     */
    public void setCollisionObjectType(CollisionObjectEnum collisionObjectType) {
        this.collisionObjectType = collisionObjectType;
    }

    
    /**
     * @return the journeyReason
     */
    public JourneyReasonEnum getJourneyReason() {
        return journeyReason;
    }

    
    /**
     * @param journeyReason the journeyReason to set
     */
    public void setJourneyReason(JourneyReasonEnum journeyReason) {
        this.journeyReason = journeyReason;
    }

    
    /**
     * @return the typeName
     */
    public static String getTypeName() {
        return TYPE_NAME;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " CarIncidentCase [policy=" + policy + ", category=" + category + ", recoveryRequired=" + recoveryRequired
                + ", recoveryLocation=" + recoveryLocation + ", collisionCause=" + collisionCause + ", collisionType="
                + collisionType + ", collisionObjectType=" + collisionObjectType + ", journeyReason=" + journeyReason
                + "]";
    }

}
