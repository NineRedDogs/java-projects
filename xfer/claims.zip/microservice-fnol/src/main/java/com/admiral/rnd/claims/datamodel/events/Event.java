package com.admiral.rnd.claims.datamodel.events;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonDiscriminator;
import org.bson.codecs.pojo.annotations.BsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.datamodel.CarIncidentCase;
import com.admiral.rnd.claims.db.DbHelperCarCase;
import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.producer.api.ICaseProducer;
import com.admiral.rnd.claims.orchestrator.exceptions.NoSuchCaseException;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@BsonDiscriminator
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "name")  
@JsonSubTypes({ @Type(value = SelfServicePrimaryContactEvent.class, name = SelfServicePrimaryContactEvent.EVENT_NAME), 
                @Type(value = SelfServiceCircumstancesEvent.class, name = SelfServiceCircumstancesEvent.EVENT_NAME), 
                @Type(value = SelfServiceVehicleEvent.class, name = SelfServiceVehicleEvent.EVENT_NAME) }) 
public abstract class Event {
    
    private static final Logger LOG = LoggerFactory.getLogger(Event.class);
    
    @JsonProperty
    @BsonProperty
    private String id;
    
    @JsonProperty
    @BsonProperty
    private String interactionId;

    @JsonProperty
    @BsonProperty(useDiscriminator = true)
    private String name;
    
    private final ObjectMapper om = new ObjectMapper();

    /**
     * @param id
     * @param interactionId
     * @param name
     */
    @JsonCreator
    public Event(
            @JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("interactionId") @BsonProperty("interactionId") String interactionId, 
            @JsonProperty("name") @BsonProperty("name") String name) {
        super();
        this.id = id;
        this.interactionId = interactionId;
        this.name = name;
    }

    @BsonCreator
    public Event() {}

    
    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    
    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    
    /**
     * @return the interactionId
     */
    public String getInteractionId() {
        return interactionId;
    }

    
    /**
     * @param interactionId the interactionId to set
     */
    public void setInteractionId(String interactionId) {
        this.interactionId = interactionId;
    }

    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Event [id=" + id + ", interactionId=" + interactionId + ", name=" + name + "]";
    }
    
    public String asJson() throws JsonProcessingException {
        return om.writeValueAsString(this);
    }
    
    
    
    // state transition stuff .....
    abstract protected List<Class<?>> getValidTransitions();
    
    public boolean validTransition(Class<?> newEvent) {
        return getValidTransitions().contains(newEvent);
    }

    public boolean canBeAnInitialEvent() {
        // default is that the event is not an initial event, override in concrete class for exceptions
        return false;
    }

    public CarIncidentCase toCarIncidentCase(DbHelperCarCase dbAccessor) throws NoSuchCaseException {
        // based on self service event type, either get a new incident case or look up previously created case related to current interaction
        final CarIncidentCase ciCase = (canBeAnInitialEvent()) ? new CarIncidentCase() : dbAccessor.getCase(getInteractionId());
        if (ciCase == null) {
            throw new NoSuchCaseException("Incident case could not be found using interaction : " + getInteractionId());
        }
        LOG.info("extracted case [" + ciCase.getClass().getName() + "] from Mongo >>\n  " + ciCase.toString());
        LOG.info("extracted case [" + ciCase.getId() + "]");

        // we've got the incident case, can now add the specific data from the current self-service event
        addSelfServiceEventData(ciCase, dbAccessor);
        
        // and finally update in the db
        dbAccessor.updateCase(ciCase);
        return ciCase;
    }
    
    protected void addSelfServiceEventData(final CarIncidentCase ciCase, DbHelperCarCase dbAccessor) {
        ciCase.setUpdatedAt(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
    }
    
    
    public void postUpdatedCase(CarIncidentCase ciCase, ICaseProducer caseProducer) {
        String incidentCaseJson ="{}";
        try {
            incidentCaseJson = om.writeValueAsString(ciCase);
            caseProducer.postEvent(ciCase.getId(), new TopicRecord(ciCase.getId(), incidentCaseJson));
        } catch (JsonProcessingException e) {
            LOG.info("Caught JsonProcessingException when generating WS Response JSON, e:" + e.getMessage());
        }
    }


}
