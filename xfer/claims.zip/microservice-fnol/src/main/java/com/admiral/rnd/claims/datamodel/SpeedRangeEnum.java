package com.admiral.rnd.claims.datamodel;

public enum SpeedRangeEnum {
    _0_TO_5, _5_TO_9, _10_TO_19, _30_TO_39, _40_PLUS
}
