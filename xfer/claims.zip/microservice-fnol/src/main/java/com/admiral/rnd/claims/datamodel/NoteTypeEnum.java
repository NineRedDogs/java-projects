package com.admiral.rnd.claims.datamodel;

public enum NoteTypeEnum {
    SUMMARY, STATEMENT, UPDATE, FNOL_WRAPUP, FINAL_WRAPUP
}
