package com.admiral.rnd.claims.datamodel;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CaseAssociation extends Entity {

    @JsonProperty
    @BsonProperty
    private CaseAssociationTypeEnum type;


    @JsonProperty
    @BsonProperty
    private String description;


    @JsonProperty
    @BsonProperty
    private String caseId;

    /**
     * @param type
     * @param description
     * @param caseId
     */
    @JsonCreator
    public CaseAssociation(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") CaseAssociationTypeEnum type,
            @JsonProperty("description") @BsonProperty("description") String description, 
            @JsonProperty("caseId") @BsonProperty("caseId") String caseId) {
        super(id, createdAt, updatedAt);
        this.type = type;
        this.description = description;
        this.caseId = caseId;
    }

    @BsonCreator
    public CaseAssociation() {}

    
    /**
     * @return the type
     */
    public CaseAssociationTypeEnum getType() {
        return type;
    }

    
    /**
     * @param type the type to set
     */
    public void setType(CaseAssociationTypeEnum type) {
        this.type = type;
    }

    
    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    
    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    
    /**
     * @return the caseId
     */
    public String getCaseId() {
        return caseId;
    }

    
    /**
     * @param caseId the caseId to set
     */
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " CaseAssociation [type=" + type + ", description=" + description + ", caseId=" + caseId + "]";
    }



}
