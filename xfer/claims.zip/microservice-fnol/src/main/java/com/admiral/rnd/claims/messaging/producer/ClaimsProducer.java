package com.admiral.rnd.claims.messaging.producer;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.admiral.rnd.claims.messaging.TopicRecord;
import com.admiral.rnd.claims.messaging.producer.api.IClaimsProducer;

public abstract class ClaimsProducer implements IClaimsProducer {
    
    private static final Logger LOG = LoggerFactory.getLogger(ClaimsProducer.class);
    
    private final String topicName;
    private final String kafkaServers;
    private Producer<String, TopicRecord> producer;
    
    /**
     * @param topic
     * @param kafkaServers
     * @param producer
     */
    public ClaimsProducer(String kafkaServers, String topic) {
        super();
        this.kafkaServers = kafkaServers;
        this.topicName = topic;
        this.producer = new KafkaProducer<String, TopicRecord>(createProducerConfig());
    }

    protected Properties createProducerConfig() {
        Properties props = new Properties();
        props.put("bootstrap.servers", kafkaServers); // can switch to multiple brokers, use a comma separated list string
        props.put("acks", "all");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("linger.ms", 1);
        props.put("buffer.memory", 33554432);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "com.admiral.rnd.claims.messaging.TopicRecordSerializer");
        return props;
    }
    
    @Override
    public void postEvent(final String key, final TopicRecord topicRecord) {
        LOG.info("- about to post event to TOPIC " + topicName);
        LOG.info("-     about to post event: key    : " + key);
        LOG.info("-     about to post event: record : " + topicRecord);
        producer.send(new ProducerRecord<String, TopicRecord>(topicName, key, topicRecord));
    }



}
