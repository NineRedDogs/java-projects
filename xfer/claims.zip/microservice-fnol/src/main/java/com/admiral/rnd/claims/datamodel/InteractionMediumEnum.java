package com.admiral.rnd.claims.datamodel;

public enum InteractionMediumEnum {
    INBOUND_CALL, OUTBOUND_CALL, INSTANCE_MESSAGE, SMS
}
