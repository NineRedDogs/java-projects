package com.admiral.rnd.claims.datamodel;


import java.util.List;

import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonProperty;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ClaimCase extends Case {
    
    protected static final String TYPE_NAME = "ClaimCase";
    
    @JsonProperty
    @BsonProperty
    private List<Contact> contacts;

    @JsonProperty
    @BsonProperty
    private boolean thirdParty;

    @JsonProperty
    @BsonProperty
    private LossAssessmentEnum assessment;

    /**
     * @param type
     * @param cases
     * @param contacts
     * @param assessment
     */
    @JsonCreator
    public ClaimCase(@JsonProperty("id") @BsonProperty("id") String id, 
            @JsonProperty("createdAt") @BsonProperty("createdAt") String createdAt,
            @JsonProperty("updatedAt") @BsonProperty("updatedAt") String updatedAt, 
            @JsonProperty("type") @BsonProperty("type") String type,
            @JsonProperty("associations") @BsonProperty("associations") List<CaseAssociation> associations, 
            @JsonProperty("module") @BsonProperty("module") String module,
            @JsonProperty("notes") @BsonProperty("notes") List<Note> notes,
            @JsonProperty("interactions") @BsonProperty("interactions") List<String> interactions,
            @JsonProperty("contacts") @BsonProperty("contacts") List<Contact> contacts,
            @JsonProperty("thirdParty") @BsonProperty("thirdParty") boolean thirdParty,
            @JsonProperty("assessment") @BsonProperty("assessment") LossAssessmentEnum assessment) {
        super(id, createdAt, updatedAt, type, associations, module, notes, interactions);
        this.contacts = contacts;
        this.thirdParty = thirdParty;
        this.assessment = assessment;
    }

    @BsonCreator
    public ClaimCase() {
    }

    
    /**
     * @return the contacts
     */
    public List<Contact> getContacts() {
        return contacts;
    }

    
    /**
     * @param contacts the contacts to set
     */
    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    
    /**
     * @return the thirdParty
     */
    public boolean isThirdParty() {
        return thirdParty;
    }

    
    /**
     * @param thirdParty the thirdParty to set
     */
    public void setThirdParty(boolean thirdParty) {
        this.thirdParty = thirdParty;
    }

    
    /**
     * @return the assessment
     */
    public LossAssessmentEnum getAssessment() {
        return assessment;
    }

    
    /**
     * @param assessment the assessment to set
     */
    public void setAssessment(LossAssessmentEnum assessment) {
        this.assessment = assessment;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return super.toString() + " ClaimCase [contacts=" + contacts + ", thirdParty=" + thirdParty + ", assessment=" + assessment + "]";
    }

    

}
