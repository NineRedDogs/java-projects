package com.admiral.rnd.claims.messaging;

import java.util.Map;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.kafka.common.serialization.Deserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TopicRecordDeserializer implements Deserializer<TopicRecord> {
    private static final Logger LOG = LoggerFactory.getLogger(TopicRecordDeserializer.class);


    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
        // Auto-generated method stub

    }

    @Override
    public TopicRecord deserialize(String topic, byte[] data) {
        LOG.debug("TopicRecord: deserialize");
        TopicRecord caseObject = SerializationUtils.deserialize(data);
        return caseObject;
    }

    @Override
    public void close() {
        // Auto-generated method stub

    }

}
